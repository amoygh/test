import os, sys, time

from qgis.core import (
    QgsApplication,
    QgsProject,
    QgsRasterLayer,
    QgsVectorLayer,
)
from qgis.analysis import QgsNativeAlgorithms

startTime = time.time()

profileDir = r"C:\Users\user\AppData\Roaming\QGIS\QGIS3\profiles\default"
#qgsApp = QgsApplication([], False)  # cannot get QGIS3.ini settings in standalone script, need profile dir
qgsApp = QgsApplication([], False, profileDir, "desktop")
qgsApp.initQgis()

# setPrefixPath works after init
QgsApplication.setPrefixPath(r"C:\OSGeo4W\apps\qgis", True)

# core plugins path
pluginsPath = os.path.join(QgsApplication.prefixPath(), "python", "plugins")
sys.path.append(pluginsPath);

# user profile plugins
sys.path.append(r"C:\Users\user\AppData\Roaming\QGIS\QGIS3\profiles\default\python\plugins")

from processing.core.Processing import Processing

QgsApplication.processingRegistry().addProvider(QgsNativeAlgorithms())
Processing.initialize()

import osgeo
print(os.path.dirname(osgeo.__file__))

from beacons.common import layer_utils

#gpkg = r"D:\Projects_Contract\Catchments\Blueberry\catch30m\watershed30_nhn10cb_albers.gpkg"
#gpkg = r"D:\tutorial2\output2.gpkg"
gpkg = r"D:\tutorial3\output.gpkg"

sys.path.append(r"C:\Users\user\AppData\Roaming\QGIS\QGIS3\profiles\default\python\plugins\beacons\algorithms\catchment_tools")
from eliminate_catchments_algorithm import EliminateCatchmentsAlgorithm
elimCatchments = EliminateCatchmentsAlgorithm()

streamsLyr = QgsVectorLayer(f"{gpkg}|layername=netstreams_final", "netstreams_final", "ogr")
demLyr = QgsRasterLayer(os.path.join(os.path.dirname(gpkg), "filled.sdat"), "filled", "gdal")
QgsProject.instance().addMapLayer(streamsLyr)
QgsProject.instance().addMapLayer(demLyr)

catchments = "catchments"
outputCatchments = "catchments_elim"

sourceCatchmentsLyr = QgsVectorLayer(f"{gpkg}|layername={catchments}", "catchments", "ogr")
layer_utils.copyLayerToGeoPkg(sourceCatchmentsLyr, outputCatchments, gpkg, QgsProject.instance().transformContext(), None)
catchmentsLyr = QgsVectorLayer(f"{gpkg}|layername={outputCatchments}", "catchments", "ogr")
QgsProject.instance().addMapLayer(catchmentsLyr)

mustContainNoStreams = True
multiplePasses = True

elimTypes = ['MULTI', 'SINGLE', 'OTHER']
elimCatchments.eliminateCatchments(catchmentsLyr, streamsLyr, demLyr, elimTypes, mustContainNoStreams, multiplePasses, None, None)


print("finished")