import os, sys, time


from qgis.core import (
    QgsApplication,
    QgsProject,
    QgsVectorLayer,
)
from qgis.analysis import QgsNativeAlgorithms

startTime = time.time()

profileDir = r"C:\Users\user\AppData\Roaming\QGIS\QGIS3\profiles\default"
#qgsApp = QgsApplication([], False)  # cannot get QGIS3.ini settings in standalone script, need profile dir
qgsApp = QgsApplication([], False, profileDir, "desktop")
qgsApp.initQgis()

# setPrefixPath works after init
QgsApplication.setPrefixPath(r"C:\OSGeo4W\apps\qgis", True)

# core plugins path
pluginsPath = os.path.join(QgsApplication.prefixPath(), "python", "plugins")
sys.path.append(pluginsPath);

# user profile plugins
sys.path.append(r"C:\Users\user\AppData\Roaming\QGIS\QGIS3\profiles\default\python\plugins")

from processing.core.Processing import Processing

QgsApplication.processingRegistry().addProvider(QgsNativeAlgorithms())
Processing.initialize()

import osgeo
print(os.path.dirname(osgeo.__file__))

from beacons.common import geometry_utils

gpkg = r"D:\Projects_Contract\Catchments\Blueberry\catch30m\watershed30_nhn10cb_albers.gpkg"
catchmentsLyr = QgsVectorLayer(f"{gpkg}|layername=repair1diss", "catchments", "ogr")
QgsProject.instance().addMapLayer(catchmentsLyr)

sys.path.append(r"C:\Users\user\AppData\Roaming\QGIS\QGIS3\profiles\default\python\plugins\beacons\algorithms\catchment_tools")

# from isolated_catchments_algorithm import IsolatedCatchmentsAlgorithm
# isolatedCatch = IsolatedCatchmentsAlgorithm()
# catchNumFieldName = "CATCHNUM"
# isolatedCatch.createIsolatedCatchments(catchmentsLyr, catchNumFieldName, None, None)

for feat in catchmentsLyr.getFeatures():
    geom = feat.geometry()
    innerRings = geometry_utils.getInteriorRings(geom)


print("finished")