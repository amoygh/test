import os, sys, datetime, time

from qgis.core import (
    QgsApplication,
    QgsProject,
    QgsRasterLayer,
    QgsVectorLayer,
)
from qgis.analysis import QgsNativeAlgorithms

startTime = time.time()

profileDir = r"C:\Users\user\AppData\Roaming\QGIS\QGIS3\profiles\default"
#qgsApp = QgsApplication([], False)  # cannot get QGIS3.ini settings in standalone script, need profile dir
qgsApp = QgsApplication([], False, profileDir, "desktop")
qgsApp.initQgis()

# setPrefixPath works after init
QgsApplication.setPrefixPath(r"C:\OSGeo4W\apps\qgis", True)

# core plugins path
pluginsPath = os.path.join(QgsApplication.prefixPath(), "python", "plugins")
sys.path.append(pluginsPath);

# user profile plugins
sys.path.append(r"C:\Users\user\AppData\Roaming\QGIS\QGIS3\profiles\default\python\plugins")

import processing
from processing.core.Processing import Processing

QgsApplication.processingRegistry().addProvider(QgsNativeAlgorithms())
Processing.initialize()

import osgeo
print(os.path.dirname(osgeo.__file__))


def compareDownstreamCatchmentFiles():
    builderDownstreamOutputFilename = r"D:\Projects_Contract\Catchments\Blueberry\catch30m\2023_01_01_0100_ROW_DOWNSTREAM_CATCHMENTS.csv"
    qgisDownstreamOutputFilename = r"D:\Projects_Contract\Catchments\Blueberry\catch30m\2023_01_01_0100_ROW_DOWNSTREAM_CATCHMENTS_QGIS.csv"

    builderDownstreamCatchments = {}
    with open(builderDownstreamOutputFilename, "r") as builderDownstreamOutputFile:
        h = builderDownstreamOutputFile.readline()
        for line in builderDownstreamOutputFile:
            lineSplit = line.rstrip().split(',')
            builderDownstreamCatchments[lineSplit[0]] = lineSplit[2:]

    qgisDownstreamCatchments = {}
    with open(qgisDownstreamOutputFilename, "r") as qgisDownstreamOutputFile:
        h = qgisDownstreamOutputFile.readline()
        for line in qgisDownstreamOutputFile:
            lineSplit = line.rstrip().split(',')
            k = lineSplit[0]
            vals = []
            for v in lineSplit[2:]:
                if len(v) > 0:
                    vals.append(v)
            qgisDownstreamCatchments[k] = vals


    for builderCatchKey in builderDownstreamCatchments.keys():
        if builderCatchKey in qgisDownstreamCatchments:
            builderCatchList = builderDownstreamCatchments[builderCatchKey]
            qgisCatchList = qgisDownstreamCatchments[builderCatchKey]
            if len(builderCatchList) == len(qgisCatchList):
                builderCatchList.sort()
                qgisCatchList.sort()
                for i in range(len(builderCatchList)):
                    if builderCatchList[i] != qgisCatchList[i]:
                        print(f"{builderCatchKey}: no match")
                        # if i == 0:
                        #     print(f"{builderCatchKey}: no match")
                        #     return

            else:
                print(f"{builderCatchKey}: len(builderCatchList) != len(qgisCatchList) {len(builderCatchList)} != {len(qgisCatchList)}")
        else:
            print(f"qgisCatchKey:{builderCatchKey} not in builderDownstreamCatchments")


    pass

# compareDownstreamCatchmentFiles()
# exit(1)

from osgeo import gdal
from osgeo.gdalconst import *

gpkg = "D:/Projects_Contract/Catchments/Blueberry/catch30m/watershed30_nhn10cb_albers.gpkg"

# catchmentsLyr = QgsVectorLayer(r"C:\temp\mtrobson\out.gpkg|layername=outputcatchments", "catchments", "ogr")
# demLyr = QgsRasterLayer(r"D:\Projects_Contract\Catchments\beacons_provider_mtrobson\mtrobson_diss_agree_filled.tif", "dem", "gdal")

# 15m
#catchmentsLyr = QgsVectorLayer(r"D:/Projects_Contract/Catchments/Blueberry/NHN10CB_Albers.gpkg|layername=watershed_nhn10cb_albers", "catchments", "ogr")

# 30m
#catchmentsLyr = QgsVectorLayer(f"{gpkg}|layername=watershed30_nhn10cb_albers_org", "catchments", "ogr")

# catchmentsLyr = QgsVectorLayer(f"{gpkg}|layername=watershed30_nhn10cb_albers_elim2", "catchments", "ogr")
# outputBreaks = f"ogr:dbname=\'{gpkg}' table=\"watershed30_nhn10cb_albers_breaks1\" (geom)"

catchmentsLyr = QgsVectorLayer(f"{gpkg}|layername=watershed30_nhn10cb_albers_repaired1", "catchments", "ogr")
outputBreaks = f"ogr:dbname=\'{gpkg}' table=\"watershed30_nhn10cb_albers_breaks2\" (geom)"

QgsProject.instance().addMapLayer(catchmentsLyr)

sys.path.append(r"C:\Users\user\AppData\Roaming\QGIS\QGIS3\profiles\default\python\plugins\beacons\algorithms\catchment_tools")
from identify_downstream_catchment_breaks_algorithm import IdentifyDownstreamCatchhmentBreaksAlgorithm

startTime = time.time()
checkCatchments = IdentifyDownstreamCatchhmentBreaksAlgorithm()
#catchnumFieldName = "ARC"
catchnumFieldName = "CATCHNUM"
uniqueLastCatchments = checkCatchments.checkCatchments(catchmentsLyr, catchnumFieldName, "ORDER1", "ORDER2", "ORDER3", "BASIN", None, None)
uniqueLastCatchments.sort()
query = f"\"{catchnumFieldName}\" IN (" + ",".join([str(c) for c in uniqueLastCatchments]) + ")"
print(query)
print(f"{len(uniqueLastCatchments)} unique")
catchmentsLyr.selectByExpression(query)

# saveResult = processing.run("native:saveselectedfeatures",
#     {'INPUT': catchmentsLyr,
#      'OUTPUT': "ogr:dbname=\'D:/Projects_Contract/Catchments/Blueberry/catch30m/watershed30_nhn10cb_albers.gpkg\' table=\"watershed30_nhn10cb_albers_breaks2\" (geom)"
#      })

saveResult = processing.run("native:saveselectedfeatures",
    {'INPUT': catchmentsLyr,
     'OUTPUT': outputBreaks
     })

print(f"finished {time.time() - startTime}s")




