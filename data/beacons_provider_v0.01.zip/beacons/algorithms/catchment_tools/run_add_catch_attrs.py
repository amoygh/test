import os, sys, datetime, time


from qgis.core import (
    QgsApplication,
    QgsProject,
    QgsRasterLayer,
    QgsVectorLayer,
)
from qgis.analysis import QgsNativeAlgorithms

startTime = time.time()

profileDir = r"C:\Users\user\AppData\Roaming\QGIS\QGIS3\profiles\default"
#qgsApp = QgsApplication([], False)  # cannot get QGIS3.ini settings in standalone script, need profile dir
qgsApp = QgsApplication([], False, profileDir, "desktop")
qgsApp.initQgis()

# setPrefixPath works after init
QgsApplication.setPrefixPath(r"C:\OSGeo4W\apps\qgis", True)

# core plugins path
pluginsPath = os.path.join(QgsApplication.prefixPath(), "python", "plugins")
sys.path.append(pluginsPath);

# user profile plugins
sys.path.append(r"C:\Users\user\AppData\Roaming\QGIS\QGIS3\profiles\default\python\plugins")

import processing
from processing.core.Processing import Processing

QgsApplication.processingRegistry().addProvider(QgsNativeAlgorithms())
Processing.initialize()

import osgeo
print(os.path.dirname(osgeo.__file__))


gpkg = r"D:\Projects_Contract\Catchments\Blueberry\catch30m\watershed30_nhn10cb_albers.gpkg"
#catchmentsLyr = QgsVectorLayer(f"{gpkg}|layername=watershed30_nhn10cb_albers_org", "catchments", "ogr")
catchmentsLyr = QgsVectorLayer(f"{gpkg}|layername=watershed30_nhn10cb_albers_repaired1", "catchments", "ogr")
streamsLyr = QgsVectorLayer(f"D:/Projects_Contract/Catchments/Blueberry/NHN10CB_Albers.gpkg|layername=streams_diss_netorder_nhn10cb_albers", "streams", "ogr")
fdaLyr = QgsVectorLayer(f"D:/Projects_Contract/Catchments/Blueberry/blueberry.gpkg|layername=bnd10CB000", "fda", "ogr")
QgsProject.instance().addMapLayer(catchmentsLyr)
QgsProject.instance().addMapLayer(streamsLyr)
QgsProject.instance().addMapLayer(fdaLyr)

sys.path.append(r"C:\Users\user\AppData\Roaming\QGIS\QGIS3\profiles\default\python\plugins\beacons\algorithms\catchment_tools")
from add_catchment_attributes_algorithm import AddCatchmentAttributesAlgorithm

addCatchAttrs = AddCatchmentAttributesAlgorithm()
#catchNumFieldName = "ARC"
catchNumFieldName = "CATCHNUM"
mdaFieldName = "WSCMDA"
fdaFieldName = "FDA"
addCatchAttrs.addCatchmentAttributes(catchmentsLyr, catchNumFieldName, streamsLyr, fdaLyr, mdaFieldName, fdaFieldName, None, None)

print("finished")