import os, sys, datetime, time


from qgis.core import (
    QgsApplication,
    QgsProject,
    QgsRasterLayer,
    QgsVectorLayer,
)
from qgis.analysis import QgsNativeAlgorithms

startTime = time.time()

profileDir = r"C:\Users\user\AppData\Roaming\QGIS\QGIS3\profiles\default"
#qgsApp = QgsApplication([], False)  # cannot get QGIS3.ini settings in standalone script, need profile dir
qgsApp = QgsApplication([], False, profileDir, "desktop")
qgsApp.initQgis()

# setPrefixPath works after init
QgsApplication.setPrefixPath(r"C:\OSGeo4W\apps\qgis", True)

# core plugins path
pluginsPath = os.path.join(QgsApplication.prefixPath(), "python", "plugins")
sys.path.append(pluginsPath);

# user profile plugins
sys.path.append(r"C:\Users\user\AppData\Roaming\QGIS\QGIS3\profiles\default\python\plugins")

import processing
from processing.core.Processing import Processing

QgsApplication.processingRegistry().addProvider(QgsNativeAlgorithms())
Processing.initialize()

import osgeo
print(os.path.dirname(osgeo.__file__))


gpkg = r"D:\Projects_Contract\Catchments\Blueberry\catch30m\watershed30_nhn10cb_albers.gpkg"
catchmentsLyr = QgsVectorLayer(r"D:/Projects_Contract/Catchments/Blueberry/catch30m/watershed30_nhn10cb_albers.gpkg|layername=watershed30_nhn10cb_albers_elim", "catchments", "ogr")
QgsProject.instance().addMapLayer(catchmentsLyr)

sys.path.append(r"C:\Users\user\AppData\Roaming\QGIS\QGIS3\profiles\default\python\plugins\beacons\algorithms\catchment_tools")
from select_downstream_catchments_algorithm import SelectDownstreamCatchmentsAlgorithm

selectCatchments = SelectDownstreamCatchmentsAlgorithm()
#seedCatchNum = 34601
seedCatchNum = 29656
catchNumFieldName = "ARC"
selectCatchments.selectDownstreamCatchments(seedCatchNum, catchmentsLyr, catchNumFieldName, "ORDER1", "ORDER2", "ORDER3", "BASIN", None, None)


print("finished")