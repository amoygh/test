import os, sys, datetime, time


from qgis.core import (
    edit,
    QgsApplication,
    QgsFeature,
    QgsGeometry,
    QgsProject,
    QgsRasterLayer,
    QgsVectorLayer,
    QgsWkbTypes
)
from qgis.analysis import QgsNativeAlgorithms

startTime = time.time()

profileDir = r"C:\Users\user\AppData\Roaming\QGIS\QGIS3\profiles\default"
#qgsApp = QgsApplication([], False)  # cannot get QGIS3.ini settings in standalone script, need profile dir
qgsApp = QgsApplication([], False, profileDir, "desktop")
qgsApp.initQgis()

# setPrefixPath works after init
QgsApplication.setPrefixPath(r"C:\OSGeo4W\apps\qgis", True)

# core plugins path
pluginsPath = os.path.join(QgsApplication.prefixPath(), "python", "plugins")
sys.path.append(pluginsPath);

# user profile plugins
sys.path.append(r"C:\Users\user\AppData\Roaming\QGIS\QGIS3\profiles\default\python\plugins")

import processing
from processing.core.Processing import Processing

QgsApplication.processingRegistry().addProvider(QgsNativeAlgorithms())
Processing.initialize()

import osgeo
print(os.path.dirname(osgeo.__file__))

from osgeo import gdal
from osgeo.gdalconst import *

from beacons.common import layer_utils

# catchmentsLyr = QgsVectorLayer(r"C:\temp\mtrobson\out.gpkg|layername=outputcatchments", "catchments", "ogr")
# demLyr = QgsRasterLayer(r"D:\Projects_Contract\Catchments\beacons_provider_mtrobson\mtrobson_diss_agree_filled.tif", "dem", "gdal")

# 15m
#catchmentsLyr = QgsVectorLayer(r"D:/Projects_Contract/Catchments/Blueberry/NHN10CB_Albers.gpkg|layername=watershed_nhn10cb_albers", "catchments", "ogr")

# 30m
gpkg = r"D:\Projects_Contract\Catchments\Blueberry\catch30m\watershed30_nhn10cb_albers.gpkg"
sourceLyr = QgsVectorLayer(f"{gpkg}|layername=testedit", "source", "ogr")
clipLyr = QgsVectorLayer(f"{gpkg}|layername=testclip", "clip", "ogr")
clippedLyrName = "testedit_clip"

layer_utils.copyLayerToGeoPkg(sourceLyr, clippedLyrName, gpkg, QgsProject.instance().transformContext(), None)
catchmentsLyr = QgsVectorLayer(f"{gpkg}|layername={clippedLyrName}", "clipped", "ogr")
QgsProject.instance().addMapLayer(catchmentsLyr)

clipFeat = next(clipLyr.getFeatures())
combinedConnectGeom = clipFeat.geometry()

FidRemapDict = {}
def getRemappedFid(inputFid):
    remappedFid = inputFid
    isGettingFid = True
    while isGettingFid:
        if remappedFid in FidRemapDict:
            remappedFid = FidRemapDict[remappedFid]
        else:
            isGettingFid = False
    return remappedFid


with edit(catchmentsLyr):
    # get catchments to modify by finding which catchments intersect combined connect geometry
    modifyCatchFids = layer_utils.doExpression(f"overlay_intersects('{catchmentsLyr.id()}', $id)", catchmentsLyr, combinedConnectGeom)
    if modifyCatchFids and len(modifyCatchFids) > 0:
        for i in range(len(modifyCatchFids)):
            modCatchFeature = catchmentsLyr.getFeature(getRemappedFid(modifyCatchFids[i]))
            moddedCatchGeom = modCatchFeature.geometry().difference(combinedConnectGeom)

            # modded catch must be polygon and have some area removed to continue
            if moddedCatchGeom.wkbType() == QgsWkbTypes.MultiPolygon or moddedCatchGeom.wkbType() == QgsWkbTypes.Polygon:
                if moddedCatchGeom.area() < modCatchFeature.geometry().area():
                    splitCatchPartGeoms = []
                    if moddedCatchGeom.wkbType() == QgsWkbTypes.MultiPolygon:
                        for multiPoly in moddedCatchGeom.asMultiPolygon():
                            splitCatchPartGeoms.append(QgsGeometry.fromPolygonXY(multiPoly))
                    else:
                        splitCatchPartGeoms.append(moddedCatchGeom)

                    canSaveSplitPart = True
                    i = 0
                    tempFidRemap = {}
                    for splitCatch in splitCatchPartGeoms:
                        if canSaveSplitPart:
                            # save split part separately
                            splitCatchFeat = QgsFeature()
                            splitCatchFeat.setGeometry(splitCatch)
                            splitCatchFeat.setFields(modCatchFeature.fields())
                            splitCatchFeat.setAttributes(modCatchFeature.attributes())
                            splitCatchFeat.setAttribute(catchmentsLyr.primaryKeyAttributes()[0], None)
                            catchmentsLyr.addFeature(splitCatchFeat)
                            tempFidRemap[modCatchFeature.id()] = splitCatchFeat.id()
                            print(f"expandModifyCatchment split:{splitCatchFeat.id()} {splitCatch.asWkt()}")
                            pass
                        i += 1
                    catchmentsLyr.deleteFeatures([getRemappedFid(modCatchFeature.id())])
                    for k in  tempFidRemap.keys():
                        FidRemapDict[k] = tempFidRemap[k]

                    downstreamNbrs = []
                    nextNbrFids = layer_utils.doExpression(f"overlay_touches('{catchmentsLyr.id()}', $id)", catchmentsLyr, combinedConnectGeom)
                    # nextNbrFids.extend(nextContainsNbrFids)
                    # nextNbrFids = list(set(nextNbrFids))
                    if nextNbrFids:
                        for nxtNbrFid in nextNbrFids:
                            nextNbrFid = getRemappedFid(nxtNbrFid)
                            nextNbrFeat = catchmentsLyr.getFeature(nextNbrFid)
                            print(f"nxtNbrFid:{nxtNbrFid} {nextNbrFeat.geometry().asWkt()}")
            else:
                # no split occured, so just save current geometry
                #catchmentsLyr.dataProvider().changeGeometryValues({modifyCatchFids[i]: moddedCatchGeom })
                pass
    else:
        print(f"No neighbouring catchments.")
        pass

    # update upstream and downstream geometry
    # catchmentsLyr.dataProvider().changeGeometryValues({upstreamCatchFeat.id(): upstreamCatchFeat.geometry()})
    # catchmentsLyr.dataProvider().changeGeometryValues({downStrmNbrFeat.id() : downStrmNbrFeat.geometry()})

print("finished")