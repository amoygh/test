import os, sys, datetime, time


from qgis.core import (
    QgsApplication,
    QgsProject,
    QgsRasterLayer,
    QgsVectorLayer,
)
from qgis.analysis import QgsNativeAlgorithms

startTime = time.time()

profileDir = r"C:\Users\user\AppData\Roaming\QGIS\QGIS3\profiles\default"
#qgsApp = QgsApplication([], False)  # cannot get QGIS3.ini settings in standalone script, need profile dir
qgsApp = QgsApplication([], False, profileDir, "desktop")
qgsApp.initQgis()

# setPrefixPath works after init
QgsApplication.setPrefixPath(r"C:\OSGeo4W\apps\qgis", True)

# core plugins path
pluginsPath = os.path.join(QgsApplication.prefixPath(), "python", "plugins")
sys.path.append(pluginsPath);

# user profile plugins
sys.path.append(r"C:\Users\user\AppData\Roaming\QGIS\QGIS3\profiles\default\python\plugins")

import processing
from processing.core.Processing import Processing

QgsApplication.processingRegistry().addProvider(QgsNativeAlgorithms())
Processing.initialize()

import osgeo
print(os.path.dirname(osgeo.__file__))

from osgeo import gdal
from osgeo.gdalconst import *

from beacons.common import layer_utils

# catchmentsLyr = QgsVectorLayer(r"C:\temp\mtrobson\out.gpkg|layername=outputcatchments", "catchments", "ogr")
# demLyr = QgsRasterLayer(r"D:\Projects_Contract\Catchments\beacons_provider_mtrobson\mtrobson_diss_agree_filled.tif", "dem", "gdal")

# 15m
#catchmentsLyr = QgsVectorLayer(r"D:/Projects_Contract/Catchments/Blueberry/NHN10CB_Albers.gpkg|layername=watershed_nhn10cb_albers", "catchments", "ogr")

# 30m
gpkg = r"D:\Projects_Contract\Catchments\Blueberry\catch30m\watershed30_nhn10cb_albers.gpkg"
#sourceCatchmentsLyr = QgsVectorLayer(f"{gpkg}|layername=watershed30_nhn10cb_albers_copy", "catchments", "ogr")
#repairedLyr = "watershed30_nhn10cb_albers_elim"

sourceCatchmentsLyr = QgsVectorLayer(f"{gpkg}|layername=watershed30_nhn10cb_albers_elim2", "catchments", "ogr")
repairLyrName = "watershed30_nhn10cb_albers_repaired1"
breaksLyrName = "watershed30_nhn10cb_albers_breaks1"

layer_utils.copyLayerToGeoPkg(sourceCatchmentsLyr, repairLyrName, gpkg, QgsProject.instance().transformContext(), None)
repairCatchmentsLyr = QgsVectorLayer(f"{gpkg}|layername={repairLyrName}", "catchments", "ogr")
catchmentBreaksLyr = QgsVectorLayer(f"{gpkg}|layername={breaksLyrName}", "breaks", "ogr")
streamsLyr =  QgsVectorLayer(r"D:\Projects_Contract\Catchments\Blueberry\NHN10CB_Albers.gpkg|layername=streams_diss_netorder_nhn10cb_albers", "streams", "ogr")

QgsProject.instance().addMapLayer(repairCatchmentsLyr)
QgsProject.instance().addMapLayer(catchmentBreaksLyr)
QgsProject.instance().addMapLayer(streamsLyr)


sys.path.append(r"C:\Users\user\AppData\Roaming\QGIS\QGIS3\profiles\default\python\plugins\beacons\algorithms\catchment_tools")
from repair_downstream_catchment_breaks_algorithm import RepairDownstreamCatchmentBreaksAlgorithm

repairCatchments = RepairDownstreamCatchmentBreaksAlgorithm()
connectDissolveTo = 'DOWNSTREAM'
splitPartDissolveTo = 'DOWNSTREAM'
cellSize = 30
#catchnumFieldName = "ARC"
catchnumFieldName = "CATCHNUM"
repairCatchments.repairCatchments(repairCatchmentsLyr, catchmentBreaksLyr, streamsLyr,
    connectDissolveTo, splitPartDissolveTo, cellSize, catchnumFieldName, "ORDER1", "ORDER2", "ORDER3", "BASIN", None, None)


print("finished")