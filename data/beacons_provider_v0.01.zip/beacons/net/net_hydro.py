#!/usr/bin/python

###################################################
#
# This perl script loads a river network database into memory
# and computes a number of network attributes on it.
# Despite its name it does not actually compute Pfafstetter coding at
# this time.
#
# The geographic database to be loaded is supposed to be a dir
# whose name will be used as the database name.  This will be a dataset
# exported using the export2proj utility.
#
# Rupert Brooks GeoAccess Division 2001
#####################################################333
# network.pl
#
# this contains code to process a hydrologic network derived from
# an arcinfo coverage, and to compute upstream downstream coding
# basins, stream order, etc
#
# based in part on Term project for Applied Artificial Intelligence
# at Carleton University School of Computer Science
# "Using Waltz Filtering in River Networks"
#
# Rupert Brooks  GeoAccess Division, 2001
###################################################
###################################################
#
#  Copyright 2002 Natural Resources Canada
#  Author Rupert Brooks
#  You can display this POD as a man page using the -M option
#
#=head1 NAME

#net_hydro.pl - processes a hydrology network.  Adds Strahler and Horton
#stream order, upstream and downstream coding, and builds a simple set
#of perceptual strokes.  Can if necessary
#infer direction of flow from the network structure.

#=head1 SYNOPSIS

#B<net_hydro.pl> [-M] [-H] [-d] I<input_network>

#=head1 DESCRIPTION

#B<net_hydro.pl> processes the network using the three-pass algorithm.
#(See references below).  It requires that the network be fully connected
#through lakes, and that the features are identified using the following
#valid values in the CLASS field of the ARCDATA table.  The classification may
#be performed using net_classify.pl.


#    INLANDSHORE      : lake shore
#    INLANDSHORE_INT  : The shore of a seasonal lake
#    COASTLINE        : Ocean / land boundary
#    COASTLINE_RMI    : Lake / Ocean boundary
#    COASTLINE_MWI    : Seasonal Lake / Ocean boundary
#    WATER_WATER_RRI  : Virtual boundary inside a LAKE
#    WATER_WATER_LLI  : Virtual boundary inside a LAKE
#    RIVER            : A flowing stream
#    SKELETON         : Virtual flowline through a LAKE
#    LAKE             : any area covered with water
#    SINK             : (nodes) a sink for the water flow
#    SOURCE           : (nodes) a source for the water flow

#net_hydro.pl will populate the following fields in the ARCDATA and
#NODEDATA tables.

#    BASIN    : The connected river system
#    ORDER1   : For up/downstream queries
#    ORDER2   : For up/downstream queries
#    ORDER3   : For up/downstream queries
#    STRAHLER : Strahler stream order
#    HORTON   : Horton stream order
#    STROKE   : Stroke number
#    UPSLEN   : longest upstream length
#    UPSAREA  : upstream area drained
#    DNSLEN   : shortest path to a sink
#    DNSAREA  : area along shortest path to sink
#    BRAID    : is this a braid, or a main stream


#=head1 OPTIONS

#=over 4

#=item B<-M>

#print(man page)

#=item B<-H>

#print(help page)

#=item B<-d>

#treat direction of flow as fixed (Otherwise solve for it).

#=back

#=head1 FILES

#=over 4

#=back
#=head2 DEPARTMENT OF NATURAL RESOURCES GEOMATICS CANADA
#=head2 LICENCE AGREEMENT FOR SOFTWARE

#THIS is a legal Agreement between you, the B<"Licensee">, and HER
#MAJESTY THE QUEEN IN RIGHT OF CANADA (B<"Canada">), represented by the
#Minister of Natural Resources.  BY DOWNLOADING THE SOFTWARE PACKAGE
#DELIVERED WITH THIS AGREEMENT, YOU ARE AGREEING TO BE BOUND BY THE
#TERMS OF THIS AGREEMENT.  IF YOU DO NOT AGREE TO THE TERMS OF THIS
#AGREEMENT, PROMPTLY EXIT THIS SITE AND DO NOT DOWNLOAD THE SOFTWARE
#AND ANY ACCOMPANYING ITEMS (including written materials).


#B<WHEREAS> Canada is the owner of the proprietary rights in the
#computer program (B<"Software">) delivered with this Agreement


#B<WHEREAS> the Licensee wishes to obtain the right to use the Software

#B<AND WHEREAS> Canada is prepared to license to the Licensee the right
#to use the Software subject to the terms and conditions hereinafter
#set forth

#B<NOW, THEREFORE,> Canada and the Licensee for valuable consideration,
#the receipt and sufficiency of which is hereby acknowledged by the
#parties, covenant and agree as follows:

#=over 4

#=item 1.

#The Licensee acknowledges that the Software is protected under the
#Copyright Act of Canada and Canada retains all copyright and other
#rights pertaining to the Software.

#=item 2.

#The Software is licensed, not sold, to the Licensee for use subject to
#the terms and conditions of this Agreement.  The Licensee owns the
#disk (s) on which the Software is recorded, but Canada retains all
#ownership interests in the Software.

#=item 3.

#The Licensee may make copies of the Software and create custom and
#derivative versions of the Software and license the use of the
#Software and custom and derivative versions of the Software to
#End-Users for any purpose whatsoever.

#=item 4.

#The Licensee shall reproduce on any copy of the Software and any
#custom and derivative versions of the Software the following copyright
#notice:

#(Describe the software)... produced under licence from Her Majesty the
#Queen in right of Canada, represented by the Minister of Natural
#Resources, with permission of Natural Resources Canada."

#=item 5.

#The Software is provided on an "as is" basis and Canada makes no
#guarantees, representations or warranties respecting the Software,
#either expressed or implied, arising by law or otherwise, including
#but not limited to, effectiveness, completeness, accuracy or fitness
#for a particular purpose.

#=item 6.

#Canada shall not be liable in respect of any claim, demand or action,
#irrespective of the nature of the cause of the claim, demand or action
#alleging any loss, injury or damages, direct or indirect, which may
#result from the Licensee's use or possession of the Software.  Canada
#shall not be liable in any way for loss of revenue or contracts, or
#any other consequential loss of any kind resulting from any defect in
#the Software.


#=item 7.

#The Licensee shall indemnify and save harmless Canada and its
#Ministers, officers, employees and agents from and against any claim,
#demand or action, irrespective of the nature of the cause of the
#claim, demand or action, alleging loss, costs, expenses, damages or
#injuries (including injuries resulting in death) arising out of the
#Licensee's use or possession of the Software.

#=item 8.

#The Licensee shall license End-Users the right to use the Software and
#custom and derivative versions of the Software by way of a written
#licensing agreement and that agreement shall impose upon End-Users the
#same conditions of exclusion of liability and indemnification in
#favour of Canada as those contained in Articles 5, 6 and 7 above.

#=item 9.

#The parties agree that Canada is under no obligation to provide
#technical support, maintenance services, update services, notices of
#latent defects or correction of defects for the Software.

#=item 10.

#The licence granted herein is non-exclusive, perpetual and
#royalty-free if the Licensee complies with the terms of this
#Agreement.  This Agreement shall terminate immediately without notice
#if the Licensee fails to comply with any of its terms.  Upon
#termination the Licensee agrees to destroy or return all copies of the
#Software and cease distribution of the Software and any custom and
#derivative versions of the Software.  End-User licences already
#granted shall be unaffected by the termination of this Agreement and
#remain subject to this Agreement.

#=item 11.

#The Licensee shall not assign any rights under this Agreement to any
#third party without the prior written consent of Canada.

#=item 12.

#This Agreement shall be interpreted in accordance with the laws in
#force in the Province of Ontario, Canada.

#=back

#=head1 DIAGNOSTICS

#=over 4

#=item NONE

#=back

#=head1 SEE ALSO

#Atlas Generalization Tools web site section on NET
#L<http://www.cim.mcgill.ca/~rbrook/atlas_gen/net.html>

#=head1 AUTHOR

#Rupert Brooks

#rbrooks at cyberus dot ca

#=cut

###################################################

import sys, getopt
import re
#from bsddb import db
#from dbfpy import dbf
#from pprint import pprint
import shelve
import os.path

codechars='0123456789=ABCDEFGHIJKLMNOPQRSTUVWXYZ_abcdefghijklmnopqrstuvwxyz'

def main(argv):
    global network
    n_args = len(argv)
    if(n_args == 2 and not(argv[0] == "-d")):
        print("Improper usage of net_hydro.py.")
        print("Usage: python net_hydro.py <input_network_file>")
        print("OR")
        print("python net_hydro.py -d <input network file>")
        exit()
    elif(n_args  > 2):
        print("Improper usage of net_hydro.py.")
        print("Usage: python net_hydro.py <input_network_file>")
        print("OR")
        print("python net_hydro.py -d <input network file>")
        exit()
    inputfile = ''
    dirfixed = 0
    if(argv[0] =="-d"):
        dirfixed = 1
        inputfile = argv[1]
    else:
        inputfile = argv[0]
    # dbm.dumb creates .bak, .dat and .dir
    # if(not(os.path.isfile(inputfile))):
    #     print("Could not find input network file " + inputfile)
    #     print("Exiting now.")
    #     exit()
    hydro(inputfile, dirfixed)

def hydro(inputfile, dirfixed):
    print("Input file is \"" + inputfile + "\"")
    if dirfixed:
        print('Using -d option"')
    print("Read in network.")

    network = shelve.open(inputfile, protocol=2, writeback=True)
    print("Finished reading network.")
    sinks = {}
    sink_nodes = []
    riverclass = "(RIVER)|(SKELETON)"
    coastclass = "(COASTLINE)"
    global arcs
    global nodes
    global numnodes
    global nodesprocessed
    global source_nodes
    global virtualsources
    global solved_nodes
    global iterationlimit

    source_nodes = []
    virtualsources = []
    iterationlimit = 10000
    arcs=network['ARCDATA']
    local = {}
    local['ARCS'] = network['ARCS']
    print("Setting arcs.")
    for k in range(0, len(arcs), 1):
        arc = arcs[k]
        value = local['ARCS'][arcs[k]['ARC_KEY']]
        if dirfixed:
            arc['REASON'] = "Manual"
        elif 'AREA' in value:
            arc['REASON'] = value['REASON']
        else:
            arc['REASON'] = "Default"

        if 'AREA' in value:
            arc['AREA'] = value['AREA']
        else:
            arc['AREA'] = 0

        if 'LENGTH' in value:
            arc['LENGTH'] = value['LENGTH']
        else:
            arc['LENGTH'] = 0
    print("Finished setting arcs.")
    numarcs = k
    print("Setting nodes.")
    nodes = network['NODEDATA']
    for k in range(0, len(nodes), 1):
        node = nodes[k]
        node['SOURCE'] = 0
        node['SINK'] = 0
        node['RIVERS'] = []
        node['COASTS'] = []
    print("Finished setting nodes.")
    numarcs = len(arcs.keys())
    numnodes = len(nodes.keys())
    print("There were " + str(numarcs) + " arcs read and " + str(numnodes) + " nodes read.")

    # sort out rivers vs coastlines, sinks sources, etc in the net

    print("Sort out rivers vs coastlines, sinks, sources, etc.")
    for k in arcs:
        arc = arcs[k]
        fn = arc['FNODE']
        tn = arc['TNODE']
        fnode = nodes[fn]
        tnode = nodes[tn]
        if(re.match(riverclass, arc['CLASS'], re.I)):
            fnode['RIVERS'].append(arc['ARC'])
            tnode['RIVERS'].append(arc['ARC'])
        if(re.match(coastclass, arc['CLASS'], re.I)):
            sinks[fn] = 1
            sinks[tn] = 1
            fnode['COASTS'].append(arc['ARC'])
            tnode['COASTS'].append(arc['ARC'])
            fnode['SINK'] = 1
            tnode['SINK'] = 1
    sink_nodes_keys = (sinks.keys())
    compute_network(sink_nodes_keys)
    strokelist = {}
    for i in arcs:
        if(arcs[i]['ORDER1'] == -1):
            arcs[i]['STROKE'] = 0
        else:
            strokelist[str(arcs[i]['BASIN']) + arcs[i]['ORDER1']] = 1
    stroke_keys = list(strokelist.keys())
    for i in range(0, len(stroke_keys), 1):
        strokelist[stroke_keys[i]] = i + 1
    for i in arcs:
        index = str(arcs[i]['BASIN']) + str(arcs[i]['ORDER1'])
        if(index in strokelist):
            arcs[i]['STROKE'] = strokelist[str(arcs[i]['BASIN']) + arcs[i]['ORDER1']]
    print("storing to disk")
    network.close()

def compute_network(sink_nodes_keys):
    global nodesprocessed
    global virtualsources
    global source_nodes
    global numnodes
    global network
    net_refresh()
    net_upstream(sink_nodes_keys)
    nl = []
    for z in range(0, numnodes, 1):
        nl.append(z)
    nodesprocessed_keys = (nodesprocessed.keys())
    net_inandout(nodesprocessed_keys)
    source_ref = source_nodes + virtualsources
    net_downstream(source_ref)
    hydro_strokes()

def net_refresh():
    print("net_refresh")
    global arcs
    global nodes
    for i in arcs:
        if('ARC' in arcs[i]):
            arc = arcs[i]
            arc['SOLVED'] = 0
            arc['DNSLEN'] = 0
            arc['UPSLEN'] = 0
            arc['DNSAREA'] = 0
            arc['UPSAREA'] = 0
            arc['STRAHLER'] = 0
            arc['HORTON'] = 0
            arc['PFAF'] = -1
            arc['ORDER1'] = -1
            arc['ORDER2'] = -1
            arc['ORDER3'] = -1
            arc['STROKE'] = -1
            arc['BASIN'] = -1
            arc['BRAID'] = -1
            arc['DIR'] = 1
    for i in nodes:
        if('NODE' in nodes[i]):
            node = nodes[i]
            node['SOLVED'] = 0
            node['DNSLEN'] = 0
            node['UPSLEN'] = 0
            node['UPSLENB'] = 0
            node['DNSAREA'] = 0
            node['UPSAREA'] = 0
            node['UPSAREAB'] = 0
            node['BASIN'] = -1
            node['INFLOW'] = []
            node['OUTFLOW'] = []
            if(node['SOURCE'] == 2):
                node['SOURCE'] = 0
    print("net_refresh_end")

def net_upstream(sink_nodes_keys):
    print("net_upstream")
    global nodes
    global basins
    solved_nodes = []
    basins = {}
    for i in sink_nodes_keys:
        node = nodes[i]
        v = node['RIVERS']
        if (len(v) > 0):
            node['DNSLEN'] = 0
            node['DNSAREA'] = 0
            node['BASIN'] = i
            basins[i] = {}
            basins[i]['ARCS'] = []
            basins[i]['NODES'] = []
            basins[i]['NODES'].append(i)
            node['SOLVED'] = 1
            solved_nodes.append(i)
    solve_upstream(solved_nodes)
    print("net_upstream_end")

def solve_upstream(solved_nodes):
    print("solve_upstream")
    global arcs
    global nodes
    global basins
    global nodesprocessed
    print("solve_upstream")
    numsolved = len(solved_nodes)
    iteration = 0
    totalnodes = 0
    totalarcs = 0
    arcsprocessed = {}
    nodesprocessed = {}
    while(numsolved > 0 and iteration < iterationlimit):
        newsolved_nodes = []
        iteration += 1
        for i in solved_nodes:
            nodesprocessed[i] = 1
            fixthese={}
            arccounter = 0
            riverlist = sorted(nodes[i]['RIVERS'])
            for j in riverlist:
                upnode = None
                if (arcs[j]['REASON'] =='Manual'):
                    fn = arcs[j]['FNODE']
                    tn = arcs[j]['TNODE']
                    if (fn == i and arcs[j]['DIR'] < 0):
                        upnode = tn
                    elif (tn == i and arcs[j]['DIR'] > 0):
                        upnode = fn
                elif (arcs[j]['SOLVED']!=1):
                    arccounter += 1
                    fn = arcs[j]['FNODE']
                    tn = arcs[j]['TNODE']
                    if (fn == i):
                        upnode = tn
                        arcs[j]['DIR'] = -1
                        arcs[j]['REASON'] = 'Computed'
                    elif(tn == i):
                        upnode = fn
                        arcs[j]['DIR'] = 1
                        arcs[j]['REASON'] = 'Computed'
                if (upnode != None):
                    arcs[j]['BASIN'] = nodes[i]['BASIN']
                    arcs[j]['DNSLEN'] = nodes[i]['DNSLEN']
                    arcs[j]['DNSAREA'] = nodes[i]['DNSAREA']
                    basins[nodes[i]['BASIN']]['ARCS'].append(j)
                    arcs[j]['SOLVED'] = 1
                    arcsprocessed[j] = 1
                    if(nodes[upnode]['SOLVED']!=1):
                        basins[nodes[i]['BASIN']]['NODES'].append(upnode)
                        nodes[upnode]['BASIN'] = nodes[i]['BASIN']
                        nodes[upnode]['DNSLEN'] = nodes[i]['DNSLEN'] + arcs[j]['LENGTH']
                        nodes[upnode]['DNSAREA'] = nodes[i]['DNSAREA'] + arcs[j]['AREA']
                        newsolved_nodes.append(upnode)
                        nodes[upnode]['SOLVED'] = 1
                    else:
                        fixthese[upnode] = 1
            backtracknodes(fixthese)
        totalnodes += numsolved
        solved_nodes = newsolved_nodes
        numsolved = len(solved_nodes)
        totalarcs += arccounter
    print("solve_upstream_end")

def backtracknodes(fixthese):
    #print("backtracknodes")
    numtofix = len(fixthese.keys())
    newfixthese = {}
    while(numtofix > 0):
        for i in fixthese.keys():
            if(i in newfixthese):
               del(newfixthese[i])
            moretofix = fixit(i)
            for j in moretofix:
                newfixthese[j] = 1
        fixthese = newfixthese
        numtofix = len(fixthese.keys())
    #print("backtracknodes_end")

def fixit(i):
    global nodes
    global arcs
    tobefixed = []
    mdtc = None
    mdtca = None
    cntme = 0
    for j in nodes[i]['RIVERS']:
        if(arcs[j]['SOLVED']==1):
            cntme += 1
            fn = arcs[j]['FNODE']
            tn = arcs[j]['TNODE']
            arclength = arcs[j]['LENGTH']
            arcarea = arcs[j]['AREA']
            fdist = nodes[fn]['DNSLEN']
            tdist = nodes[tn]['DNSLEN']
            farea = nodes[fn]['DNSAREA']
            tarea = nodes[tn]['DNSAREA']
            joinbasins(nodes[i]['BASIN'], arcs[j]['BASIN'])
            if(arcs[j]['REASON'] == "Manual"):
                if(fn == i and arcs[j]['DIR'] > 0):
                    d = arclength + tdist
                    da = arcarea + tarea
                elif(fn == i and arcs[j]['DIR'] > 0):
                    d = arclength + tdist
                    da = arcarea + tarea
                else:
                    d = None
                    da = None
            else:
                if(fn == i):
                    d = arclength + tdist
                    da = arcarea + tarea
                else:
                    d = arclength + fdist
                    da = arcarea + farea
            if(d != None):
                if(mdtc != None):
                    if(mdtc < d):
                        mdtc = mdtc
                        mdtca = mdtca
                    else:
                        mdtc = d
                        mdtca = da
                else:
                    mdtc = d
                    mdtca = da
    if(mdtc == None):
        print("Undefined mdtc at node " + str(nodes[i]['NODE']))
        sys.exit()
    nodes[i]['DNSLEN'] = mdtc
    nodes[i]['DNSAREA'] = mdtca
    for j in nodes[i]['RIVERS']:
        upnode = 1
        if (arcs[j]['REASON'] == "Manual"):
            upnode = None
            fn = arcs[j]['FNODE']
            tn = arcs[j]['TNODE']
            if(fn == i and arcs[j]['DIR'] < 0):
                upnode = tn
            elif(tn == i and arcs[j]['DIR'] > 0):
                upnode = fn
        if((arcs[j]['SOLVED'] == 1) and upnode != None):
            fn = arcs[j]['FNODE']
            tn = arcs[j]['TNODE']
            arclength = arcs[j]['LENGTH']
            arcarea = arcs[j]['AREA']
            fdist = nodes[fn]['DNSLEN']
            tdist = nodes[tn]['DNSLEN']
            farea = nodes[fn]['DNSAREA']
            tarea = nodes[tn]['DNSAREA']
            dir = arcs[j]['DIR']
            if(fn == i):
                oppnode = tn
                if(dir > 0):
                    faceout = 1
                else:
                    faceout = 0
            else:
                oppnode = fn
                if(dir < 0):
                    faceout = 1
                else:
                    faceout = 0
            if(faceout):
                if(arcs[j]['DNSLEN'] > mdtc):
                    x = 0
                    print("Flipping arc " + str(j) + ".")
            else:
                if(arcs[j]['ARC_KEY'] == 1):
                    print("Arc " + str(j) + " MDTC " + str(mdtc))
                arcs[j]['DNSLEN'] = mdtc
                arcs[j]['DNSAREA'] = mdtca
                nodes[oppnode]['DNSLEN'] = mdtc + arcs[j]['LENGTH']
                nodes[oppnode]['DNSAREA'] = mdtca + arcs[j]['AREA']
                if(nodes[oppnode]['DNSLEN'] >= mdtc):
                    print("Faces in and ok")
                else:
                    print("Flipping (2) arc " + str(j))
    return tobefixed

def joinbasins(b1, b2):
    global arcs
    global basins
    global nodes
    if(not(b1 == b2)):
        for i in basins[b2]['ARCS']:
            arcs[i]['BASIN'] = b1
            basins[b1]['ARCS'].append(i)
        for i in basins[b2]['NODES']:
            nodes[i]['BASIN'] = b1
            basins[b1]['NODES'].append(i)
        del(basins[b2])

def net_inandout(nodelist):
    global nodes
    global arcs
    global virtualsources
    for i in nodelist:
        if(nodes[i]['SOLVED']==1):
            nodes[i]['INFLOW'] = []
            nodes[i]['OUTFLOW'] = []
            for j in nodes[i]['RIVERS']:
                if(arcs[j]['DIR'] > 0):
                    if(arcs[j]['TNODE'] == i):
                        nodes[i]['INFLOW'].append(j)
                    else:
                        nodes[i]['OUTFLOW'].append(j)
                else:
                    if(arcs[j]['FNODE'] == i):
                        nodes[i]['INFLOW'].append(j)
                    else:
                        nodes[i]['OUTFLOW'].append(j)
            numin = len(nodes[i]['INFLOW'])
            if(numin == 0 and not(nodes[i]['SOURCE'] > 0)):
                nodes[i]['SOURCE'] = 2
                virtualsources.append(i)

def net_downstream(source_ref):
    print("net_downstream")
    global nodes
    global solved_nodes
    solved_nodes = []
    source_nodes = source_ref
    for i in source_nodes:
        if (nodes[i]['SOLVED'] == 1):
            nodes[i]['UPSLEN'] = 0
            nodes[i]['UPSAREA'] = 0
            nodes[i]['STRAHLER'] = 1
            solved_nodes.append(i)
    solve_downstream()
    print("net_downstream end")

def solve_downstream():
    print("solve_downstream")
    global solved_nodes
    global arcs
    global nodes
    arccounter = 0
    numsolved = len(solved_nodes)
    iteration = 0
    totalnodes = 0
    totalarcs = 0
    while(numsolved > 0):
        newsolvednodes = {}
        iteration+=1
        if(iteration > iterationlimit):
            break
        arcounter = 0
        for i in solved_nodes:
            maxstrahler = 1
            strahlercount = 0
            cont = 1
            upslen = 0
            upslenb = 0
            upsarea = 0
            upsareab = 0
            notbraidcount = 0
            inflowcount = len(nodes[i]['INFLOW'])

            for j in nodes[i]['INFLOW']:
                strahler = arcs[j]['STRAHLER']
                braid = arcs[j]['BRAID']
                ul = arcs[j]['UPSLEN'] + arcs[j]['LENGTH']
                ua = arcs[j]['UPSAREA'] + arcs[j]['AREA']
                if(braid):
                    if(upslenb > ul):
                        upslenb = upslenb
                    else:
                        upslenb = ul
                    upsareab += ua
                else:
                    notbraidcount+=1
                    if(upslen > ul):
                        upslen = upslen
                    else:
                        upslen = ul
                upsarea += ua
                if(strahler == 0):
                    cont = 0
                    newsolvednodes[i] = 1
                elif(strahler == maxstrahler):
                    if(not(braid)):
                        strahlercount+=1
                elif(strahler > maxstrahler):
                    maxstrahler = strahler
                    if(braid):
                        strahlercount = 0
                    else:
                        strahlercount = 1
            if(cont):
                if(strahlercount > 1):
                    strahler = maxstrahler + 1
                else:
                    strahler = maxstrahler
                if((notbraidcount > 0) or (inflowcount == 0)):
                    mainfound = 0
                else:
                    mainfound = 1
                for j in nodes[i]['OUTFLOW']:
                    arccounter += 1
                    if(not(mainfound)):
                        ldiff = abs(arcs[j]['DNSLEN'] + arcs[j]['LENGTH'] - nodes[i]['DNSLEN'])
                        if(ldiff < 0.001):
                            arcs[j]['BRAID'] = 0
                            arcs[j]['UPSLEN'] = upslen
                            arcs[j]['UPSAREA'] = upsarea
                        else:
                            arcs[j]['BRAID'] = 1
                            arcs[j]['UPSLEN'] = upslenb
                            arcs[j]['UPSAREA'] = upsareab
                    else:
                        arcs[j]['BRAID'] = 1
                        arcs[j]['UPSLEN'] = upslenb
                        arcs[j]['UPSAREA'] = upsareab
                    arcs[j]['STRAHLER'] = strahler
                    if(arcs[j]['DIR'] > 0):
                        dnnode = arcs[j]['TNODE']
                    else:
                        dnnode = arcs[j]['FNODE']
                    newsolvednodes[dnnode] = 1
                nodes[i]['UPSLEN'] = upslen
                nodes[i]['UPSLENB'] = upslenb
                nodes[i]['UPSAREA'] = upsarea
        totalnodes += numsolved
        oldsolved_nodes = solved_nodes
        solved_nodes = list(newsolvednodes.keys())
        l1 = len(oldsolved_nodes)
        l2 = len(solved_nodes)
        arrsame = 0
        if(l1 == l2):
            arrsame = 1
            for z in range(0, l1, 1):
                if(oldsolved_nodes[z] != solved_nodes[z]):
                    arrsame = 0
                if(not(arrsame)):
                    break
        if(arrsame):
            print("WARNING: Cycle detected on nodes:")
            print("Iteration " + str(iteration) + str(solved_nodes))
        if(arrsame):
            break
        numsolved = len(solved_nodes)
        totalarcs += arccounter
    print("solve_downstream end")

def hydro_strokes():
    print("hydro_strokes")
    global basins
    global strokes
    global queue
    strokes = {}
    basin_len = len(basins)
    basins_keys = basins.keys()
    for b in basins_keys:
        basin_sinks = getbasinsinks(b)
        basin_sinks_len = len(basin_sinks)
        if(basin_sinks_len > 0):
            queue = []
            s = makehydrostroke(basin_sinks[0], 'A')
            basins[b]['STROKE'] = s
            while(len(queue) > 0):
                qlist = queue.pop(0)
                strokes[qlist[0]]['CHILDREN'].append(makehydrostroke(qlist[1],qlist[2]))
            basin_sinks_len = len(basin_sinks)
            for i in range(basin_sinks_len-1, 0, -1):
                hs = makehydrostroke(basin_sinks[i], "00")
                strokes[s]['CHILDREN'].insert(0, hs)
                basin_sinks_len -= 1
            while(len(queue) > 0):
                qlist = queue.pop(0)
                strokes[qlist[0]]['CHILDREN'].append(makehydrostroke(qlist[1],qlist[2]))
    compute_ordercodes()
    compute_horton()
    print("hydro_strokes end")

def getbasinsinks(b):
    global basins
    global nodes
    #print("getbasinsinks")
    sinks_local = []
    for i in basins[b]['NODES']:
        if(nodes[i]['SINK'] > 0):
            j = 0
            if(len(sinks_local) > 0):
                for j in range(0, len(sinks_local), 1):
                    if(nodes[sinks_local[j]]['UPSLEN'] <= nodes[i]['UPSLEN']):
                        break
            sinks_local.append(i)
    #print("getbasinsinks end")
    return sinks_local


def makehydrostroke(cn, parent):
    global strokes
    global nodes
    global arcs
    global queue
    #print("makehydrostroke")
    cs = len(strokes)+1
    if(not(cs in strokes)):
        strokes[cs] = {}
    strokes[cs]['ARCS'] = []
    strokes[cs]['NODES'] = []
    strokes[cs]['NODES'].append(cn)
    strokes[cs]['LENGTH'] = 0
    strokes[cs]['CHILDREN'] = []
    strokes[cs]['PARENT'] = parent
    done = 0
    count = 0
    while(not(done)):
        length = 0
        braid = 1
        children = []
        a = None
        oldcount = count
        for arc in nodes[cn]['INFLOW']:
            if(arcs[arc]['STROKE'] < 0):
                if(braid and (arcs[arc]['BRAID'] == 0 or (length < (arcs[arc]['LENGTH'] + arcs[arc]['UPSLEN'])))):
                    braid = arcs[arc]['BRAID']
                    if(not(a == None)):
                        children.append(a)
                    a = arc
                    length = arcs[arc]['LENGTH'] + arcs[arc]['UPSLEN']
                    count = oldcount + 1
                elif (not(braid) and (arcs[arc]['BRAID'] == 0) and (length < (arcs[arc]['LENGTH'] + arcs[arc]['UPSLEN']))):
                    children.append(a)
                    a = arc
                    length = arcs[arc]['LENGTH'] + arcs[arc]['UPSLEN']
                    count = oldcount + 1
                else:
                    children.append(arc)
        if(len(children) > 0):
            dig2str = b64_2dig(oldcount)
            qlist = []
            qlist.append(cs)
            qlist.append(cn)
            qlist.append(dig2str)
            queue.append(qlist)
        if(not(a == None)):
            dig2str = b64_2dig(count)
            arcs[a]['STROKE'] = cs
            arcs[a]['ORDER3'] = dig2str
            strokes[cs]['ARCS'].append(a)
            if(arcs[a]['DIR'] > 0):
                cn = arcs[a]['FNODE']
            else:
                cn = arcs[a]['TNODE']
            strokes[cs]['NODES'].append(cn)
            strokes[cs]['LENGTH'] += arcs[a]['LENGTH']
        else:
            done = 1
    #print("makehydrostroke end")
    return cs

def compute_ordercodes():
    global basins
    global strokes
    global arcs
    print("compute_ordercodes")
    strokelist = []
    for b in basins:
        s = basins[b]['STROKE']
        strokes[s]['ORDER1'] = ".00"
        strokelist.append(s)
        ac = 0
        for j in strokes[s]['ARCS']:
            arcs[j]['ORDER2'] = ac
            ac += 1
    while(len(strokelist) > 0):
            i = strokelist.pop(0)
            p = strokes[i]['ORDER1']
            lastpar = ''
            for j in strokes[i]['CHILDREN']:
                par = strokes[j]['PARENT']
                if(lastpar != par):
                    c = 1
                lastpar = par
                if(c > 63):
                    print("Maximum stroke valency of 63 exceeded at " + str(p) + "," + str(par))
                    sys.exit()
                strokes[j]['ORDER1'] = p + par + b64(c)
                c += 1
                strokelist.append(j)
            ac = 1
            for j in strokes[i]['ARCS']:
                arcs[j]['ORDER1'] = p
                arcs[j]['ORDER2'] = ac
                ac += 1
    print("compute_ordercodes end")

def compute_horton():
    global arcs
    global strokes
    for i in strokes:
        if(len(strokes[i]['ARCS']) > 0):
            horton = arcs[strokes[i]['ARCS'][0]]['STRAHLER']
            for j in strokes[i]['ARCS']:
                arcs[j]['HORTON'] = horton

def b64(i):
    ib64 = codechars[i]
    return ib64

def b64_2dig(a):
    global codechars
    if(not(a < 4096 and a >= 0)):
        print(str(a) + " is out of range for encoding.")
        sys.exit()
    i = a%64
    j = (a - i)/64
    ib64 = codechars[i]
    jb64 = codechars[int(j)]
    dig2str = jb64 + ib64
    return  dig2str

if __name__ == "__main__":
    main(sys.argv[1:])
    #main([r"c:\temp\streamcoast.net"])
