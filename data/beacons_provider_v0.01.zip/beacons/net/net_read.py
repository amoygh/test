#!/usr/bin/python

####################################################
#
#  Copyright 2002 Natural Resources Canada
#  Author Rupert Brooks
#  You can display this POD as a man page using the -M option
#

#net_read.py - reads in a network from a set of dbf files.

#B<net_read.py> I<input_network_root_name> I<output_network>

#B<net_read.py> reads in a network stored in a set of dbf files
#corresponding to the topology tables for Arc/Info.  The I<root name>
#refers to the part of the name of all the dbf files which is the same.
#For example, if the network is stored in amazingnet_aat.dbf,
#amazingnet_nat.dbf, amazingnet_trn.dbf, then the root name is
#amazingnet.

#Net_read builds a python shelve structure in memory
#and then writes that out to a shelve file.  This file can be used
#as input by the other tools in the Net software suite.

#Net_read.py expects data to come in in up to 5 dbf files for a given dataset.  These files will be named with the dataset prefix, followed by an extension indicating their type. For the purpose of reading in data Net will read in any or all of these tables that are present, or that you tell it to on the command line. Which tables you need is dependent on what algorithm you intend to use.

#These tables exactly correspond to the topology tables that ArcInfo Workstation uses. At this time, the only supported way to generate them is using ArcInfo. An aml to generate them is provided in net_prepare.aml. However you prepare them, note that NET trusts you to provide good data and does not do any consistency checking of the input. The possible input files are

#    <prefix>_aat.dbf : The Arc feature table
#    <prefix>_nat.dbf : The Node feature table
#    <prefix>_pat.dbf : The Polygon feature table
#    <prefix>_pal.dbf : The Polygon Arc List
#    <prefix>_trn.dbf : The Turn table

#=head2 DEPARTMENT OF NATURAL RESOURCES GEOMATICS CANADA
#=head2 LICENCE AGREEMENT FOR SOFTWARE

#THIS is a legal Agreement between you, the B<"Licensee">, and HER
#MAJESTY THE QUEEN IN RIGHT OF CANADA (B<"Canada">), represented by the
#Minister of Natural Resources.  BY DOWNLOADING THE SOFTWARE PACKAGE
#DELIVERED WITH THIS AGREEMENT, YOU ARE AGREEING TO BE BOUND BY THE
#TERMS OF THIS AGREEMENT.  IF YOU DO NOT AGREE TO THE TERMS OF THIS
#AGREEMENT, PROMPTLY EXIT THIS SITE AND DO NOT DOWNLOAD THE SOFTWARE
#AND ANY ACCOMPANYING ITEMS (including written materials).


#B<WHEREAS> Canada is the owner of the proprietary rights in the
#computer program (B<"Software">) delivered with this Agreement;


#B<WHEREAS> the Licensee wishes to obtain the right to use the Software;

#B<AND WHEREAS> Canada is prepared to license to the Licensee the right
#to use the Software subject to the terms and conditions hereinafter
#set forth;

#B<NOW, THEREFORE,> Canada and the Licensee for valuable consideration,
#the receipt and sufficiency of which is hereby acknowledged by the
#parties, covenant and agree as follows:

#=over 4

#=item 1.

#The Licensee acknowledges that the Software is protected under the
#Copyright Act of Canada and Canada retains all copyright and other
#rights pertaining to the Software.

#=item 2.

#The Software is licensed, not sold, to the Licensee for use subject to
#the terms and conditions of this Agreement.  The Licensee owns the
#disk (s) on which the Software is recorded, but Canada retains all
#ownership interests in the Software.

#=item 3.

#The Licensee may make copies of the Software and create custom and
#derivative versions of the Software and license the use of the
#Software and custom and derivative versions of the Software to
#End-Users for any purpose whatsoever.

#=item 4.

#The Licensee shall reproduce on any copy of the Software and any
#custom and derivative versions of the Software the following copyright
#notice:

#(Describe the software)... produced under licence from Her Majesty the
#Queen in right of Canada, represented by the Minister of Natural
#Resources, with permission of Natural Resources Canada."

#=item 5.

#The Software is provided on an "as is" basis and Canada makes no
#guarantees, representations or warranties respecting the Software,
#either expressed or implied, arising by law or otherwise, including
#but not limited to, effectiveness, completeness, accuracy or fitness
#for a particular purpose.

#=item 6.

#Canada shall not be liable in respect of any claim, demand or action,
#irrespective of the nature of the cause of the claim, demand or action
#alleging any loss, injury or damages, direct or indirect, which may
#result from the Licensee's use or possession of the Software.  Canada
#shall not be liable in any way for loss of revenue or contracts, or
#any other consequential loss of any kind resulting from any defect in
#the Software.


#=item 7.

#The Licensee shall indemnify and save harmless Canada and its
#Ministers, officers, employees and agents from and against any claim,
#demand or action, irrespective of the nature of the cause of the
#claim, demand or action, alleging loss, costs, expenses, damages or
#injuries (including injuries resulting in death) arising out of the
#Licensee's use or possession of the Software.

#=item 8.

#The Licensee shall license End-Users the right to use the Software and
#custom and derivative versions of the Software by way of a written
#licensing agreement and that agreement shall impose upon End-Users the
#same conditions of exclusion of liability and indemnification in
#favour of Canada as those contained in Articles 5, 6 and 7 above.

#=item 9.

#The parties agree that Canada is under no obligation to provide
#technical support, maintenance services, update services, notices of
#latent defects or correction of defects for the Software.

#=item 10.

#The licence granted herein is non-exclusive, perpetual and
#royalty-free if the Licensee complies with the terms of this
#Agreement.  This Agreement shall terminate immediately without notice
#if the Licensee fails to comply with any of its terms.  Upon
#termination the Licensee agrees to destroy or return all copies of the
#Software and cease distribution of the Software and any custom and
#derivative versions of the Software.  End-User licences already
#granted shall be unaffected by the termination of this Agreement and
#remain subject to this Agreement.

#=item 11.

#The Licensee shall not assign any rights under this Agreement to any
#third party without the prior written consent of Canada.

#=item 12.

#This Agreement shall be interpreted in accordance with the laws in
#force in the Province of Ontario, Canada.

#=back

#=head1 DIAGNOSTICS

#=over 4

#=item NONE

#=back

#=head1 SEE ALSO

#Atlas Generalization Tools web site section on NET
#L<http://www.cim.mcgill.ca/~rbrook/atlas_gen/net.html>

#=head1 AUTHOR

#Rupert Brooks

#rbrooks at cyberus dot ca

#=cut

###################################################

import sys, getopt
import re
#from bsddb import db
#from dbfpy import dbf
#from pprint import pprint
import shelve
import os.path

def getFieldNameIndexLookup(fieldNames):
    fieldNameIndexDict = {}
    fi = 0
    for fn in fieldNames:
        fieldNameIndexDict[fn] = fi
        fi += 1
    return fieldNameIndexDict

def main(argv):
    inputfile = ''
    outputfile = ''
    n_args = len(argv)
    print(str(n_args) + str(argv))
    if(not(n_args == 3)):
        print("Usage: python net_read.py <input_network_name> <file ext> <output_network_filename>")
        exit()
    inputfile = argv[0]
    fileTypeExt = argv[1]
    outputfile = argv[2]
    read(inputfile, fileTypeExt, outputfile)

def read(inputfile, fileTypeExt, outputfile):
    print("Input network name is \"" + inputfile + "\".")
    print("File ext is \"" + fileTypeExt + "\".")
    print("Output network file is \"" + outputfile + "\".")

    path_file = inputfile.split(os.path.sep)
    filename = path_file[-1]
    pathname = os.path.sep.join(path_file[0:-1]) + os.path.sep
    if(not(outputfile)):
        exit()
    else:
        if fileTypeExt.upper() == ".DBF":
            try:
                from dbfpy import dbf
            except ModuleNotFoundError as err:
                print(err)
                return None
    
        network = shelve.open(outputfile, writeback=True)
        arctable = pathname + filename + "_aat" +  fileTypeExt
        polytable = pathname + filename + "_pat" +  fileTypeExt
        paltable = pathname + filename + "_pal" +  fileTypeExt
        nodetable = pathname + filename + "_nat" + fileTypeExt
        turntable = pathname + filename + "_trn" + fileTypeExt
        if(not(os.path.isfile(arctable))):
            arctable = 0
        if(not(os.path.isfile(polytable))):
            polytable = 0
        if(not(os.path.isfile(paltable))):
            paltable = 0
        if(not(os.path.isfile(nodetable))):
            nodetable = 0
        if(not(os.path.isfile(turntable))):
            turntable = 0
        if(not(arctable) and not(polytable) and not(paltable) and not(nodetable) and not(turntable)):
            print("ERROR:No tables found to load in")
            exit()
        network['VERSION'] = "Nettools Planar Graph V3.2"
        if(arctable):
            print("Now load the arc table")
            network['ARCS'] = {}
            
            if fileTypeExt.upper() == ".DBF":
                arcdb = dbf.Dbf(arctable)
                for rec in arcdb:
                    network['ARCS'][rec['ARC_KEY']] = {}
                    for fn in arcdb.fieldNames:
                        network['ARCS'][rec['ARC_KEY']][fn] = rec[fn]
            else:
                print("Loading CSV arc table.")
                with open(arctable) as arctableFile:
                    headerLine = arctableFile.readline()
                    fieldNames = headerLine.strip('\n').split(",")
                    fieldNameIndexLookup = getFieldNameIndexLookup(fieldNames)
                    for line in arctableFile:
                        rec = line.strip("\n").split(",")
                        arcKey = int(rec[fieldNameIndexLookup['ARC_KEY']])
                        network['ARCS'][arcKey] = {}
                        for fn in fieldNames:
                            if fn.upper() == 'LENGTH':
                                network['ARCS'][arcKey][fn] = float(rec[fieldNameIndexLookup[fn]])
                            else:
                                network['ARCS'][arcKey][fn] = int(rec[fieldNameIndexLookup[fn]])

            arcs = {}
            arcindex = {}
            i = 0
            arcs_dict = network['ARCS']
            for k in arcs_dict.keys():
                arcindex[k] = i
                arcs[i] = {}
                arcs[i]['ARC'] = i
                arcs[i]['ARC_KEY'] = k
                i += 1
        if(nodetable):
            node_outputfile = "node_" + outputfile
            print("Now load the node table.")

            if fileTypeExt.upper() == ".DBF":
                nodedb = dbf.Dbf(nodetable);
                i = 1;
                network['NODES'] = {};
                for rec in nodedb:
                    network['NODES'][i] = {};
                    for fn in nodedb.fieldNames:
                        network['NODES'][rec['NODE_KEY']][fn] = rec[fn];
                    i += 1;
            else:
                print("Loading CSV node table.")
                with open(nodetable) as nodetableFile:
                    headerLine = nodetableFile.readline()
                    fieldNames = headerLine.strip('\n').split(",")
                    fieldNameIndexLookup = getFieldNameIndexLookup(fieldNames)
                    i = 1
                    network['NODES'] = {};
                    for line in nodetableFile:
                        rec = line.strip("\n").split(",")
                        nodeKey = int(rec[fieldNameIndexLookup['NODE_KEY']])
                        network['NODES'][i] = {}
                        for fn in fieldNames:
                            if fn.upper() == 'X_COORD' or fn.upper() == 'Y_COORD':
                                network['NODES'][nodeKey][fn] = float(rec[fieldNameIndexLookup[fn]])
                            else:
                                network['NODES'][nodeKey][fn] = int(rec[fieldNameIndexLookup[fn]])
                        i += 1

            nodes = {}
            nodeindex = {}
            i = 0
            nodes_dict = network['NODES']
            for k in nodes_dict.keys():
                nodeindex[k] = i
                nodes[i] = {}
                nodes[i]['NODE'] = i
                nodes[i]['NODE_KEY'] = k
                nodes[i]['ARCS'] = []
                i += 1
            for k in arcs_dict:
                arcs[k-1]['FNODE'] = nodeindex[arcs_dict[arcs[k-1]['ARC_KEY']]['FNODE_KEY']]
                nodes[arcs[k-1]['FNODE']]['ARCS'].append(arcs[k-1]['ARC'])
                arcs[k-1]['TNODE'] = nodeindex[arcs_dict[arcs[k-1]['ARC_KEY']]['TNODE_KEY']]
                nodes[arcs[k-1]['TNODE']]['ARCS'].append(-arcs[k-1]['ARC'])
            network['NODEDATA'] = nodes
            network['NODEINDEX'] = nodeindex
        network['ARCDATA'] = arcs
        network['ARCINDEX'] = arcindex
    network.close()


if __name__ == "__main__":
   main(sys.argv[1:])
   #main([r"D:\Projects_Contract\Catchments\runnet2\data\test_albers_net", ".dbf", r"D:\Projects_Contract\Catchments\runnet2\data\out_new.net"])
   #main([r"C:\temp\streamcoast", ".csv", r"C:\temp\streamcoast.net"])
