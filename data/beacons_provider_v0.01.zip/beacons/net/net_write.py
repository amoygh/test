#!/usr/bin/python

###################################################
#
#  Copyright 2002 Natural Resources Canada
#  Author Rupert Brooks
#  You can display this POD as a man page using the -M option
#
#=head1 NAME

#net_write.py - writes out elements from the network to various formats

#=head1 SYNOPSIS

#B<net_write.py> I<config_file> I<input_network>

#=head1 DESCRIPTION

#B<net_write.py> uses the descriptions of what elements should go in a
#table (or tables) from the input configuration file, and produces an
#output table according to these specifications.

#The configuration file is a text file, which contains blocks of text
#for each table to be processed.  Each such block starts with a line
#with the keyword TABLE followed by the name of the table (use %b to
#access the name of the input data and %p to access the path) and the
#format.  Supported formats are DBF, TXT, CSV and SCREEN.  Each block
#ends with the END keyword Within the block, there are an arbitrary
#number of lines.  Each line describes an item in the resulting table.
#The first entry is the desired name of the item, the second entry is
#the table in the network to fetch the item from and the third entry is
#the name of the item, inside the network.  The fourth item describes
#the format, which is really only relevant to the DBF output format.

#For Example:

 # Example Configuration file for net_write
 #
 # in the table name, a %b puts in the basename for the file
 # %p puts in the path name to the data.
 # eg, for ../blah/foo.net, the basename is foo
 # in order for arcinfo to convert the fields logically, it is
 # necessary to specify them in certain ways
 # integer = num(7,0)
 # double = num(8 or more,x)
#ORDER1 ARCDATA ORDER1 char(254)
# TABLE %p%b_nodedata DBF
#       NODE NODEDATA NODE_KEY num(7,0)
#       CLASS NODEDATA CLASS char(20)
#       SOLVED NODEDATA SOLVED num(7,0)
#       DNSLEN NODEDATA DNSLEN num(15,2)
#       UPSLEN NODEDATA UPSLEN num(15,2)
#       DNSAREA NODEDATA DNSAREA num(15,2)
#       UPSAREA NODEDATA UPSAREA num(15,2)
#       RIVERS NODEDATA RIVERS num(7,0)
#       COASTS NODEDATA COASTS num(7,0)
#       INFLOW NODEDATA INFLOW num(7,0)
#       OUTFLOW NODEDATA OUTFLOW num(7,0)
#       BASIN NODEDATA BASIN num(7,0)
# END
# TABLE %b_arcdata DBF
#       ARC ARCDATA ARC_KEY num(7,0)
#       CLASS ARCDATA CLASS char(20)
#       SOLVED ARCDATA SOLVED num(7,0)
#       DNSLEN ARCDATA DNSLEN num(15,2)
#       UPSLEN ARCDATA UPSLEN num(15,2)
#       DNSAREA ARCDATA DNSAREA num(15,2)
#       UPSAREA ARCDATA UPSAREA num(15,2)
#       BASIN ARCDATA BASIN num(7,0)
#       DIR ARCDATA DIR num(7,0)
#       BRAID ARCDATA BRAID num(7,0)
#       STRAHLER ARCDATA STRAHLER num(7,0)
#       HORTON ARCDATA HORTON num(7,0)
#       PFAF ARCDATA PFAF char(20)
#       STROKE ARCDATA STROKE num(7,0)
#       ORDER1 ARCDATA ORDER1 char(254)
#       ORDER2 ARCDATA ORDER2 num(7,0)
#       ORDER3 ARCDATA ORDER3 char(30)
# END


#=head1 OPTIONS

#=over 4

#=item B<-M>

#print(man page)

#=item B<-H>

#print(help page)

#=back

#=head1 FILES

#=over 4

#=back

#=head1 LICENSE

#=head2 DEPARTMENT OF NATURAL RESOURCES GEOMATICS CANADA

#=head2 LICENCE AGREEMENT FOR SOFTWARE

#THIS is a legal Agreement between you, the B<"Licensee">, and HER
#MAJESTY THE QUEEN IN RIGHT OF CANADA (B<"Canada">), represented by the
#Minister of Natural Resources.  BY DOWNLOADING THE SOFTWARE PACKAGE
#DELIVERED WITH THIS AGREEMENT, YOU ARE AGREEING TO BE BOUND BY THE
#TERMS OF THIS AGREEMENT.  IF YOU DO NOT AGREE TO THE TERMS OF THIS
#AGREEMENT, PROMPTLY EXIT THIS SITE AND DO NOT DOWNLOAD THE SOFTWARE
#AND ANY ACCOMPANYING ITEMS (including written materials).


#B<WHEREAS> Canada is the owner of the proprietary rights in the
#computer program (B<"Software">) delivered with this Agreement


#B<WHEREAS> the Licensee wishes to obtain the right to use the Software

#B<AND WHEREAS> Canada is prepared to license to the Licensee the right
#to use the Software subject to the terms and conditions hereinafter
#set forth

#B<NOW, THEREFORE,> Canada and the Licensee for valuable consideration,
#the receipt and sufficiency of which is hereby acknowledged by the
#parties, covenant and agree as follows:

#=over 4

#=item 1.

#The Licensee acknowledges that the Software is protected under the
#Copyright Act of Canada and Canada retains all copyright and other
#rights pertaining to the Software.

#=item 2.

#The Software is licensed, not sold, to the Licensee for use subject to
#the terms and conditions of this Agreement.  The Licensee owns the
#disk (s) on which the Software is recorded, but Canada retains all
#ownership interests in the Software.

#=item 3.

#The Licensee may make copies of the Software and create custom and
#derivative versions of the Software and license the use of the
#Software and custom and derivative versions of the Software to
#End-Users for any purpose whatsoever.

#=item 4.

#The Licensee shall reproduce on any copy of the Software and any
#custom and derivative versions of the Software the following copyright
#notice:

#(Describe the software)... produced under licence from Her Majesty the
#Queen in right of Canada, represented by the Minister of Natural
#Resources, with permission of Natural Resources Canada."

#=item 5.

#The Software is provided on an "as is" basis and Canada makes no
#guarantees, representations or warranties respecting the Software,
#either expressed or implied, arising by law or otherwise, including
#but not limited to, effectiveness, completeness, accuracy or fitness
#for a particular purpose.

#=item 6.

#Canada shall not be liable in respect of any claim, demand or action,
#irrespective of the nature of the cause of the claim, demand or action
#alleging any loss, injury or damages, direct or indirect, which may
#result from the Licensee's use or possession of the Software.  Canada
#shall not be liable in any way for loss of revenue or contracts, or
#any other consequential loss of any kind resulting from any defect in
#the Software.


#=item 7.

#The Licensee shall indemnify and save harmless Canada and its
#Ministers, officers, employees and agents from and against any claim,
#demand or action, irrespective of the nature of the cause of the
#claim, demand or action, alleging loss, costs, expenses, damages or
#injuries (including injuries resulting in death) arising out of the
#Licensee's use or possession of the Software.

#=item 8.

#The Licensee shall license End-Users the right to use the Software and
#custom and derivative versions of the Software by way of a written
#licensing agreement and that agreement shall impose upon End-Users the
#same conditions of exclusion of liability and indemnification in
#favour of Canada as those contained in Articles 5, 6 and 7 above.

#=item 9.

#The parties agree that Canada is under no obligation to provide
#technical support, maintenance services, update services, notices of
#latent defects or correction of defects for the Software.

#=item 10.

#The licence granted herein is non-exclusive, perpetual and
#royalty-free if the Licensee complies with the terms of this
#Agreement.  This Agreement shall terminate immediately without notice
#if the Licensee fails to comply with any of its terms.  Upon
#termination the Licensee agrees to destroy or return all copies of the
#Software and cease distribution of the Software and any custom and
#derivative versions of the Software.  End-User licences already
#granted shall be unaffected by the termination of this Agreement and
#remain subject to this Agreement.

#=item 11.

#The Licensee shall not assign any rights under this Agreement to any
#third party without the prior written consent of Canada.

#=item 12.

#This Agreement shall be interpreted in accordance with the laws in
#force in the Province of Ontario, Canada.

#=back

#=head1 DIAGNOSTICS

#=over 4

#=item NONE

#=back

#=head1 REQUIRES

#Perl v5.6.0, GetOpt::Long, Pod::Usage, Data::Dumper, DB_File, DBI,
#DBD::XBase, Term::ReadLine, MLDBM ,Data::Dumper, Storable

#=head1 SEE ALSO

#Atlas Generalization Tools web site section on NET
#L<http://www.cim.mcgill.ca/~rbrook/atlas_gen/net.html>

#=head1 AUTHOR

#Rupert Brooks

#rbrooks at cyberus dot ca

#=cut

###################################################

import sys, getopt
import re
import shelve
#import dbf
import os

def main(argv):
    configfile = ''
    netfile = ''

    n_args = len(argv)
    if(not(n_args == 2)):
        print("Improper usage of net_write.py.")
        print("Usage: python net_write.py <configfile> <input network>")
        exit()
    configfile = argv[0]
    if(not(os.path.isfile(configfile))):
        print("Could not find configuration file " + configfile)
        print("Exiting now.")
        exit()
    netfile = argv[1]
    # dbm.dumb creates .bak, .dat and .dir
    # if(not(os.path.isfile(netfile))):
    #     print("Could not find input network file " + netfile)
    #     print("Exiting now.")
    #     exit()
    write(configfile, netfile)

def write(configfile, netfile):
    print("Configuration file is " + "\"" + configfile + "\"")
    print("Input network file is " + "\"" + netfile + "\"")

    form_csv = re.compile('^CSV$')
    form_tab = re.compile('^TAB$')
    form_dbf = re.compile('^DBF$')
    form_scr = re.compile('^SCREEN$')

    path_base = netfile.split(os.path.sep)
    basename = path_base[-1].split('.')[0]
    if(len(path_base) > 1):
        pathname = os.path.sep.join(path_base[0:-1]) + os.path.sep
    else:
        pathname = ""
    tablelist = {}
    ct = ""
    state = 0
    CFG = open(configfile,"r")
    for line in CFG:
        line = line.partition('#')[0]
        line = line.rstrip()
        fields = line.split()
        if(fields):
            if(state == 0):
                if (re.match('TABLE', fields[0], re.I)):
                    if (re.match('(CSV)|(TAB)|(DBF)|(SCREEN)', fields[2], re.I)):
                        ct = fields[1]
                        ct = re.sub(r'\%b', basename, ct)
                        ct = re.sub(r'\%p', pathname.encode('unicode-escape').decode(), ct)
                        tablelist[ct] = {}
                        tablelist[ct]['FIELDS'] = []
                        tablelist[ct]['FORMAT'] = fields[2]
                        tablelist[ct]['FILE'] = ct
                        state = 1
                    else:
                        print("Incorrect file format")
                else:
                    print("Error in file format")
            else:
                if(re.match('END', fields[0], re.I)):
                    state = 0
                else:
                    name = fields[0]
                    table  = fields[1]
                    key = fields[2]
                    fmt = fields[3]
                    if(fmt == ""):
                        print("Incorrect specification.")
                        sys.exit()
                    l = {}
                    l['NAME'] = name
                    l['TABLE'] = table
                    l['KEY'] = key
                    if(tablelist[ct]['FORMAT'] == "DBF"):
                        if(fmt[:4] == "char"):
                            fmt = fmt.replace("char", "C")
                        elif(fmt[:3] == "num"):
                            fmt = fmt.replace("num", "N")
                    l['FORMAT'] = fmt
                    tablelist[ct]['FIELDS'].append(l)
    CFG.close()
    network = shelve.open(netfile, writeback=True)
    null = 0

    tableOutput = {}
    for i in tablelist:
        t = tablelist[i]
        if(form_csv.match(t['FORMAT'])):
            ofs = ","
        else:
            ofs = "\t"
        outfile = t['FILE']
        if(form_csv.match(t['FORMAT']) or form_tab.match(t['FORMAT'])):
            outfile = outfile + ".csv"
            OUT = open(outfile,"w")
            print("Outputting the text file " + outfile)
        elif(form_dbf.match(t['FORMAT'])):
            outfile = outfile + ".dbf"
            print("Outputting to the dbf file " + outfile)
        elif(form_scr.match(t['FORMAT'])):
            print("Outputting to the screen")
        else:
            print("Unknown output type " + t['FORMAT'])
            sys.exit()
        names = []
        tables = []
        keys = []
        formats = []
        for j in t['FIELDS']:
            names.append(j['NAME'])
            tables.append(j['TABLE'])
            keys.append(j['KEY'])
            formats.append(j['FORMAT'])
        if(form_csv.match(t['FORMAT']) or form_tab.match(t['FORMAT'])):
            OUT.write(ofs.join(names))
            OUT.write("\n")
        elif(form_scr.match(t['FORMAT'])):
            print(ofs.join(names))
        else:
            array = []
            array2 = []
            field_desc = ""
            for z in range(len(names)):
                field_desc = field_desc + " " + (names[z] + " " + formats[z] + "")
            field_desc = field_desc[:-1]

            try:
                from dbfpy import dbf
            except ModuleNotFoundError as err:
                print(err)
                return None

            out_table = dbf.Table(outfile, field_desc, read_only=False)
            out_table.open()
        tab_arc = re.compile('ARC', re.I)
        tab_node = re.compile('NODE', re.I)
        tab_poly = re.compile('POLY', re.I)
        if(tab_arc.match(tables[0])):
            table = 'ARCS'
            table2 = 'ARCDATA'
            key = 'ARC_KEY'
            index = network['ARCINDEX']
        elif(tab_node.match(tables[0])):
            table = 'NODES'
            table2 = 'NODEDATA'
            key = 'NODE_KEY'
            index = network['NODEINDEX']
        elif(tab_poly.match(tables[0])):
            table = 'POLY'
            table2 = 'POLYDATA'
            key = 'POLY_KEY'
            index = network['POLYINDEX']
        else:
            table = tables[0]
            table2 = None
        num_str = re.compile('num', re.I)
        char_str = re.compile('char', re.I)
        loadeddata = network[table]
        if(not(table2 == None)):
            loadeddata2 = network[table2]
        for n in loadeddata:
            if((n%10000) == 0):
                    print("Outputting record number " + str(n))
            j = loadeddata[n]
            data = []
            for k in range(0, len(tables), 1):
                if(tables[k] == table):
                    item = j[keys[k]]
                else:
                    item = loadeddata2[index[j[key]]][keys[k]]
                if((form_csv.match(t['FORMAT']) or form_tab.match(t['FORMAT']))):
                    if(char_str.match(formats[k])):
                        item = "\"" + str(item) + "\""
                    else:
                        item = str(item)
                elif(form_dbf.match(t['FORMAT'])):
                    if(formats[k][:1] == "C"):
                        item = "\"" + str(item) + "\""
                    elif(isinstance(item, list)):
                        item = id(item)
                data.append(item)
            if(form_csv.match(t['FORMAT']) or form_tab.match(t['FORMAT'])):
                OUT.write(ofs.join(data))
                OUT.write("\n")
            elif(form_dbf.match(t['FORMAT'])):
                record = out_table.append()
                for z in range(len(names)):
                    record[names[z].lower()] = data[z]
                record.write_record()
        print("Completed outputting to " + outfile)
        if(form_csv.match(t['FORMAT']) or form_tab.match(t['FORMAT'])):
            OUT.close()
        elif(form_dbf.match(t['FORMAT'])):
            out_table.close()
        tableOutput[t['FIELDS'][0]['TABLE']] = outfile
    return tableOutput

if __name__ == "__main__":
   main(sys.argv[1:])
   #main([r"C:\Users\user\AppData\Roaming\QGIS\QGIS3\profiles\default\python\plugins\beacons\net\net_maketablesconfig.cfg", r"C:\temp\streamcoast.net"])
