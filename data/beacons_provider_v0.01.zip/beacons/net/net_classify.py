#!/usr/bin/python

###################################################
#
#  Copyright 2002 Natural Resources Canada
#  Author Rupert Brooks
#  You can display this POD as a man page using the -M option
#
#=head1 NAME

#net_classify.py - assigns values to the class item in the ARCDATA,
#NODEDATA and POLYDATA tables - if they exist - based on the
#information in a configuration file.  The configuration file specifies
#conditions that must be met in the attributes in the ARCS, NODES, and
#POLYS tables and the corresponding class that must be assigned.

#=head1 SYNOPSIS

#B<net_classify.py> [-H] [ -M] I<config_file> I<input_network>

#=head1 DESCRIPTION

#B<net_classify.py> assigns values to the class item in the ARCDATA,
#NODEDATA and POLYDATA tables - if they exist - based on the
#information in a configuration file.  The configuration file specifies
#conditions that must be met in the attributes in the ARCS, NODES, and
#POLYS tables and the corresponding class that must be assigned.

#The configuration file is a text file, which contains blocks of text
#for each table to be processed.  Each such block starts with the name
#of the table, for example, ARCS, and ends with END, on a line by
#themselves.  Within the block, there are an arbitrary number of pairs
#of lines.  The first line in a pair is specifies properties that must
#be met, and the second line specifies the class that must be assigned.
#The property may be specified as the single word DEFAULT, which
#matches everything, or as a set of pairs of attribute name and value.
#Any line, or part of a line, that begins with # is treated as a
#comment and ignored.

#Note that the matching is done from top to bottom, and later matches
#overwrite earlier ones.  Therefore, put the most general parameters
#(such as DEFAULT) at the top of the file.

#For example:

 # this is an example configuration file
 # It is for converting the Geobase 0 Hydrology
 # coding scheme into something which can be used
 # more generally by the hydro processing and
 # generalisation tools.  A config file may be
 # written to convert any particular dataset to
 # this set of codes, and allow its processing
 # by the hydro tools
# ARCS
#    DEFAULT
#    UNCODED
#    F_CODE BH210 # the inland shore
#    INLANDSHORE
#    F_CODE BH141 # the inland shore - intermittent
#    INLANDSHORE_INT
#    F_CODE BA010 # the coastline
#    COASTLINE
#    F_CODE VT001 VTR 2 # the coastline
#    COASTLINE_RMI
#    F_CODE VT001 VTR 5 # the coastline
#    COASTLINE_MWI
#    F_CODE VT001 VTR 3
#    WATER_WATER_RRI
#    F_CODE VT001 VTR 4
#    WATER_WATER_LLI
#    F_CODE BH140
#    RIVER
#    F_CODE VT001 VTR 1
#    SKELETON
# END
# POLYS
#    F_CODE BH000
#    LAKE
# END
# NODES
#    DEFAULT
#    UNCODED
#    YSS 1
#    SINK
#    YSS 2
#    SOURCE
# END
#=head2 DEPARTMENT OF NATURAL RESOURCES GEOMATICS CANADA
#=head2 LICENCE AGREEMENT FOR SOFTWARE

#THIS is a legal Agreement between you, the B<"Licensee">, and HER
#MAJESTY THE QUEEN IN RIGHT OF CANADA (B<"Canada">), represented by the
#Minister of Natural Resources.  BY DOWNLOADING THE SOFTWARE PACKAGE
#DELIVERED WITH THIS AGREEMENT, YOU ARE AGREEING TO BE BOUND BY THE
#TERMS OF THIS AGREEMENT.  IF YOU DO NOT AGREE TO THE TERMS OF THIS
#AGREEMENT, PROMPTLY EXIT THIS SITE AND DO NOT DOWNLOAD THE SOFTWARE
#AND ANY ACCOMPANYING ITEMS (including written materials).


#B<WHEREAS> Canada is the owner of the proprietary rights in the
#computer program (B<"Software">) delivered with this Agreement


#B<WHEREAS> the Licensee wishes to obtain the right to use the Software

#B<AND WHEREAS> Canada is prepared to license to the Licensee the right
#to use the Software subject to the terms and conditions hereinafter
#set forth

#B<NOW, THEREFORE,> Canada and the Licensee for valuable consideration,
#the receipt and sufficiency of which is hereby acknowledged by the
#parties, covenant and agree as follows:

#=over 4

#=item 1.

#The Licensee acknowledges that the Software is protected under the
#Copyright Act of Canada and Canada retains all copyright and other
#rights pertaining to the Software.

#=item 2.

#The Software is licensed, not sold, to the Licensee for use subject to
#the terms and conditions of this Agreement.  The Licensee owns the
#disk (s) on which the Software is recorded, but Canada retains all
#ownership interests in the Software.

#=item 3.

#The Licensee may make copies of the Software and create custom and
#derivative versions of the Software and license the use of the
#Software and custom and derivative versions of the Software to
#End-Users for any purpose whatsoever.

#=item 4.

#The Licensee shall reproduce on any copy of the Software and any
#custom and derivative versions of the Software the following copyright
#notice:

#(Describe the software)... produced under licence from Her Majesty the
#Queen in right of Canada, represented by the Minister of Natural
#Resources, with permission of Natural Resources Canada."

#=item 5.

#The Software is provided on an "as is" basis and Canada makes no
#guarantees, representations or warranties respecting the Software,
#either expressed or implied, arising by law or otherwise, including
#but not limited to, effectiveness, completeness, accuracy or fitness
#for a particular purpose.

#=item 6.

#Canada shall not be liable in respect of any claim, demand or action,
#irrespective of the nature of the cause of the claim, demand or action
#alleging any loss, injury or damages, direct or indirect, which may
#result from the Licensee's use or possession of the Software.  Canada
#shall not be liable in any way for loss of revenue or contracts, or
#any other consequential loss of any kind resulting from any defect in
#the Software.


#=item 7.

#The Licensee shall indemnify and save harmless Canada and its
#Ministers, officers, employees and agents from and against any claim,
#demand or action, irrespective of the nature of the cause of the
#claim, demand or action, alleging loss, costs, expenses, damages or
#injuries (including injuries resulting in death) arising out of the
#Licensee's use or possession of the Software.

#=item 8.

#The Licensee shall license End-Users the right to use the Software and
#custom and derivative versions of the Software by way of a written
#licensing agreement and that agreement shall impose upon End-Users the
#same conditions of exclusion of liability and indemnification in
#favour of Canada as those contained in Articles 5, 6 and 7 above.

#=item 9.

#The parties agree that Canada is under no obligation to provide
#technical support, maintenance services, update services, notices of
#latent defects or correction of defects for the Software.

#=item 10.

#The licence granted herein is non-exclusive, perpetual and
#royalty-free if the Licensee complies with the terms of this
#Agreement.  This Agreement shall terminate immediately without notice
#if the Licensee fails to comply with any of its terms.  Upon
#termination the Licensee agrees to destroy or return all copies of the
#Software and cease distribution of the Software and any custom and
#derivative versions of the Software.  End-User licences already
#granted shall be unaffected by the termination of this Agreement and
#remain subject to this Agreement.

#=item 11.

#The Licensee shall not assign any rights under this Agreement to any
#third party without the prior written consent of Canada.

#=item 12.

#This Agreement shall be interpreted in accordance with the laws in
#force in the Province of Ontario, Canada.

#=back

#=head1 DIAGNOSTICS

#=over 4

#=item NONE

#=back

#=head1 SEE ALSO

#Atlas Generalization Tools web site section on NET
#L<http://www.cim.mcgill.ca/~rbrook/atlas_gen/net.html>

#=head1 AUTHOR

#Rupert Brooks

#rbrooks at cyberus dot ca

#=cut

###################################################

import sys, getopt
import shelve
import re
import os
#from pprint import pprint

def main(argv):
    inputfile = ''
    outputfile = ''
    n_args = len(argv)
    if(not(n_args == 2)):
        print("Improper usage of net_classify.py.")
        print("Usage: python net_classify.py <input classification file> <input network file>")
        exit()
    inputfile = argv[0]
    if(not(os.path.isfile(inputfile))):
        print("Could not find configuration file " + inputfile)
        print("Exiting now.")
        exit()
    outputfile = argv[1]
    # dbm.dumb creates .bak, .dat and .dir
    # if(not(os.path.isfile(outputfile))):
    #     print("Could not find input network file " + outputfile)
    #     print("Exiting now.")
    #     exit()
    classify(inputfile, outputfile)

def classify(inputfile, outputfile):
    print("Input configuration file is \"" + inputfile + "\"")
    print("Output network file is \"" + outputfile + "\"")

    path_file = inputfile.split(os.path.sep)
    filename = path_file[-1]
    pathname = os.path.sep.join(path_file[0:-1]) + os.path.sep
    datatables = dict(ARCS= 'ARCDATA', NODES='NODEDATA', POLYS='POLYDATA')
    indextables = dict(ARCS= 'ARCINDEX', NODES='NODEINDEX', POLYS='POLYINDEX')
    keylist = dict(ARCS= 'ARC_KEY', NODES='NODE_KEY', POLYS='POLY_KEY')
    CFG = open(inputfile,"r")
    rulelist = {}
    state = 0
    ct = ""
    for line in CFG:
        line = line.partition('#')[0]
        Line = line.rstrip()
        fields = line.split()
        if fields:
            print(fields)
            if state == 0:
               exp = re.compile('(ARCS)|(NODES)|(POLYS)')
               if len(fields) > 1 and not(re.match(exp, fields[0])):
                  print("Error in config file format near ")
                  print(line)
               else:
                  ct = fields[0]
                  state = 1
                  rulelist[ct] = []
            else:
                if (re.match(r'^\W*END\W*$', line, re.I)):
                  state = 0
                else:
                    if((len(fields) - 1)%2 != 1):
                        print(fields[0])
                        if(re.match('DEFAULT', fields[0], re.I)):
                            fields.append( '.*')
                            print("default" + fields[0] + fields[1])
                        else:
                            print("Error in coding file format near " + line)
                    line = next(CFG)
                    line = line.partition('#')[0]
                    line = line.rstrip()
                    x = line.split()
                    l = []
                    l = fields + x
                    rulelist[ct].append(l)
    CFG.close()

    print("Attempting to load network shelve structure.")
    network = shelve.open(outputfile, writeback=True)
    for key, value in rulelist.items():
        datakey = datatables[key]
        indexkey = indextables[key]
        keykey = keylist[key]
        if key in network:
            loadeddata = network[key]
            loadeddata2 = network[datakey]
            loadedindex = network[indexkey]
            for i in loadeddata.keys():
                for j in value:
                    rule = j
                    match = 0
                    for k in range(0,len(rule)-1,2):
                        Re = rule[k+1]
                        if rule[k] == 'DEFAULT' and k==0:
                            #print("--YES default")
                            match = 1
                        elif (rule[k] in loadeddata[i]):
                            if(re.match(str(loadeddata[i][rule[k]]), Re, re.I)):
                                match = 1
                                #print("--YES" + str(loadeddata[i]))
                        else:
                            match = 0
                    if(match):
                        if not(keykey in loadeddata[i]):
                            loadeddata[i][keykey] = {}
                        loadeddata2[loadedindex[loadeddata[i][keykey]]]['CLASS'] = rule[-1]
            network[datakey]=loadeddata2
    network.close()

if __name__ == "__main__":
   main(sys.argv[1:])
   #main([r"D:\Projects_Contract\NET\net_classifyhydro_nhn2.cfg", r"D:\Projects_Contract\NET\NET_group5\out.net"])
