import networkx as nx
import geopandas as gpd
from shapely.geometry import Point

def geoToGraph(gdf):
    """Creates graph from geodataframe."""
    fields = list(gdf.columns)
    g = nx.MultiDiGraph()
    g.graph['approach'] = "primal"
    g.graph['crs'] = gdf.crs
    # print(f"geoToGraph -> g.graph['crs']: {g.graph['crs']}")

    key = 0
    for row in gdf.itertuples():
        first = row.geometry.coords[0]
        last = row.geometry.coords[-1]

        data = list(row)[1:]
        attributes = dict(zip(fields, data))
        g.add_edge(first, last, key=key, **attributes)
        # print(f"{key},{first},{last},{attributes['arc_key']}")
        key += 1
    return g

def graphToGeo(g, edgeIDKey, nodeIDKey):
    """Create geodataframe nodes and edges from graph."""
    for nodeId, nodePt in enumerate(g):
        g.nodes[nodePt][nodeIDKey] = nodeId
        # print(f"{nodePt},{nodeIDKey},{nodeId}")

    edgesGDF = edgesToGeo(g, nodeIDKey)
    nodesGDF = nodesToGeo(g, edgeIDKey)
    # print("edgesGDF")
    # print(edgesGDF)
    # print("nodesGDF")
    # print(nodesGDF)
    return edgesGDF, nodesGDF

def edgesToGeo(g, nodeIDKey):
    """Create lines geodataframe from graph edges."""
    startPts, endPts, data = zip(*g.edges(data=True))
    # print('startPts')
    # print(startPts)
    # print('endPts')
    # print(endPts)
    # print('data')
    # print(data)

    edgesGDF = gpd.GeoDataFrame(list(data))
    if 'crs' in g.graph:
        edgesGDF.crs = g.graph['crs']
        #print(f"edges g.graph['crs']:{g.graph['crs']}\nedgesGDF.crs:{edgesGDF.crs}")

    edgesGDF['node_start'] = [g.nodes[s][nodeIDKey] for s in startPts]
    edgesGDF['node_end'] = [g.nodes[e][nodeIDKey] for e in endPts]
    return edgesGDF
def nodesToGeo(g, edgeIDKey):
    """Create points geodataframe from graph nodes."""
    #nodePts, nodeData = zip(*g.nodes(data=True))
    #g2 = g.to_undirected()

    newDataList = []
    print(f"nodesToGeo g.nodes:{len(g.nodes())}")
    for pt,data in g.nodes(data=True):
        # assign edge that node belongs to.  Use first adj edge, if node has many edges.
        data = data.copy()
        dataAdded = False

        ptSuccEdges = g.successors(pt)
        for  nbr in ptSuccEdges:
            edgeDataDict = g.get_edge_data(pt, nbr)
            if edgeDataDict:
                for k, edgeData in edgeDataDict.items():
                    data[edgeIDKey] = int(edgeData[edgeIDKey])
                    newDataList.append(data)
                    dataAdded = True
                    break
                # print(f"Succ:{data}")
                break

        if not dataAdded:
            ptPredEdges = g.predecessors(pt)
            for  nbr in ptPredEdges:
                edgeDataDict = g.get_edge_data(nbr, pt)
                if edgeDataDict:
                    for k, edgeData in edgeDataDict.items():
                        data[edgeIDKey] = int(edgeData[edgeIDKey])
                        newDataList.append(data)
                        dataAdded = True
                        break
                    # print(f"Pred:{data}")
                    break

        # ptEdges = g.adj[pt]
        # for nbr, dataDict in ptEdges.items():
        #     print(f"nbr: {nbr} dataDict: {dataDict} g:{g[nbr]}")
        #     # print(type(dataDict.keys()))
        #     data = data.copy()
        #     data[edgeIDKey] = int(dataDict[list(dataDict.keys())[0]][edgeIDKey])
        #     newDataList.append(data)
        #     break;


    nodePts, nodeData = zip(*g.nodes(data=True))
    ptsGeom = [Point(*p) for p in nodePts]

    # print("newDataList")
    # print(newDataList)
    # print("ptsGeom")
    # print(ptsGeom)

    ptsGDF = gpd.GeoDataFrame(newDataList, geometry=ptsGeom)
    if 'crs' in g.graph:
        ptsGDF.crs = g.graph['crs']
        #print(f"nodes g.graph['crs']:{g.graph['crs']}\nptsGDF.crs:{ptsGDF.crs}")
    return ptsGDF


if __name__ == '__main__':
    #streamsGDF = gpd.read_file(r'D:\Projects_Contract\Catchments\runnet2\data\test_albers2.shp')
    #streamsGDF = gpd.read_file(r'D:\temp\nhn_rhn_01aa000_gdb_en\NHN_01AA000_2_0.gdb', layer='NHN_HN_NLFLOW_1')
    #streamsGDF = gpd.read_file(r'D:\temp\nhn_rhn_01aa000_shp_en\NHN_01AA000_2_0_HN_NLFLOW_1.shp')
    #streamsGDF = gpd.read_file(r'D:\temp\nhn_rhn_01aa000_shp_en', layer='NHN_01AA000_2_0_HN_NLFLOW_1')
    #streamsGDF = gpd.read_file(r'C:/Users/user/AppData/Local/Temp/processing_tfmRGF/1ef570e2736a46a39138cff889160a0d/output.gpkg')

    #streamsGDF = gpd.read_file(r"C:\temp\net.gpkg", layer='streamCoastMergeSPNo0')
    streamsGDF = gpd.read_file(r"C:\temp\net.gpkg", layer='streamCoastMergeSPNo0')


    if True:
        #streamsGDF = streamsGDF.copy()
        graph = geoToGraph(streamsGDF.explode())
        edgeIDKey = 'arc_key'
        nodeIDKey = 'node_id'
        edges, nodes = graphToGeo(graph, edgeIDKey, nodeIDKey)
        edges.to_file(r'D:\Projects_Contract\Catchments\runnet2\temp\test_albers2_edges.shp')
        nodes.to_file(r'D:\Projects_Contract\Catchments\runnet2\temp\test_albers2_nodes.shp')

        # for index, node in nodes.iterrows():
        #     print(node[edgeIDKey], node[nodeIDKey], node['geometry'].x, node['geometry'].y)
        #
        # for index, edge in edges.iterrows():
        #     print(edge['geometry'].length, edge['node_start'], edge['node_end'])

        exit(1)


    if False:
        # using momepy
        import momepy
        graph = momepy.gdf_to_nx(streamsGDF, approach="primal")

        # f, ax = plt.subplots(1, 3, figsize=(18, 6), sharex=True, sharey=True)
        # streams.plot(color='#e32e00', ax=ax[0])
        # for i, facet in enumerate(ax):
        #     facet.set_title(("Streams", "Primal graph", "Overlay")[i])
        #     facet.axis("off")
        # nx.draw(graph, {n:[n[0], n[1]] for n in list(graph.nodes)}, ax=ax[1], node_size=15)
        # streams.plot(color='#e32e00', ax=ax[2], zorder=-1)
        # nx.draw(graph, {n:[n[0], n[1]] for n in list(graph.nodes)}, ax=ax[2], node_size=15)
        #plt.show()

        nodes, edges = momepy.nx_to_gdf(graph, points=True, lines=True)
        for index, node in nodes.iterrows():
            print(node['nodeID'], node['geometry'].x, node['geometry'].y)

        for index, edge in edges.iterrows():
            print(edge['node_start'], edge['node_end'])

        exit(1)