import os.path
import math
import numpy

from osgeo import gdal
from osgeo import ogr
from beacons.common import gdal_utils

from qgis.core import (
    Qgis,
    QgsRasterFileWriter,
    QgsRasterPipe,
    QgsRasterProjector
)



class RasterInfo():
    def __init__(self, src, data, noData, rows, cols, extent, width, height, cellWidth, cellHeight):
        self._src = src
        self._data = data
        self._noData = noData
        self._rows = rows
        self._cols = cols
        self._extent = extent
        self._width = width
        self._height = height
        self._cellWidth = cellWidth
        self._cellHeight = cellHeight

    @property
    def src(self):
        return self._src

    @src.setter
    def value(self, src):
        self._src = src

    @property
    def data(self):
        return self._data

    @data.setter
    def value(self, data):
        self._data = data

    @property
    def noData(self):
        return self._noData

    @noData.setter
    def value(self, noData):
        self._noData = noData

    @property
    def rows(self):
        return self._rows

    @rows.setter
    def value(self, rows):
        self._rows = rows

    @property
    def cols(self):
        return self._cols

    @cols.setter
    def value(self, cols):
        self._cols = cols

    @property
    def extent(self):
        return self._extent

    @extent.setter
    def extent(self, extent):
        self._dirIndex =extent

    @property
    def width(self):
        return self._width

    @width.setter
    def value(self, width):
        self._cols = width

    @property
    def height(self):
        return self._height

    @cols.setter
    def value(self, height):
        self._height = height

    @property
    def cellWidth(self):
        return self._cellWidth

    @cols.setter
    def value(self, cellWidth):
        self._cellWidth = cellWidth

    @property
    def cellHeight(self):
        return self._cellHeight

    @cellHeight.setter
    def value(self, cellHeight):
        self._cellHeight = cellHeight


def getRasterInfo(lyr):
    provider = lyr.dataProvider()
    src = gdal.Open(str(lyr.source()))
    arry = src.ReadAsArray()
    noData = int(provider.sourceNoDataValue(1))
    arry = arry.astype(numpy.float64, copy=False)
    rows = arry.shape[0]
    cols = arry.shape[1]
    arry[numpy.isnan(arry)] = noData
    extent = provider.extent()
    width = provider.xSize()
    height = provider.ySize()
    cellWidth = extent.width() / width
    cellHeight = extent.height() / height
    info = RasterInfo(src, arry, noData, rows, cols, extent, width, height, cellWidth, cellHeight)
    return info

def copyLayerToGeopackage(lyr, name, gpkg):
    ds = ogr.Open(gpkg, True)
    if lyr.isValid():
        provider = lyr.dataProvider()
        fw = QgsRasterFileWriter(gpkg)
        fw.setOutputFormat('gpkg')
        opts = [f"RASTER_TABLE={name}", "COMPRESS=LZW"]
        if os.path.isfile(gpkg):
            opts.append('APPEND_SUBDATASET=YES')
        fw.setCreateOptions(opts)
        pipe = QgsRasterPipe()
        if pipe.set(provider.clone()):
            projector = QgsRasterProjector()
            projector.setCrs(provider.crs(), provider.crs())
            if pipe.insert(2, projector):
                writerResult = fw.writeRaster(pipe, provider.xSize(), provider.ySize(), provider.extent(), provider.crs())
                if writerResult != Qgis.RasterFileWriterResult.NoError:
                    raise Exception(f"Error: Copying {lyr.name()} to {gpkg}. {Qgis.RasterFileWriterResult(writerResult).name}({writerResult})")
    else:
        raise Exception(f"Error: Layer {lyr.name()} is invalid.")

def getRasterData(rastLyr, dataType):
    noData = rastLyr.dataProvider().sourceNoDataValue(1)

    rasterDataset = gdal.Open(str(rastLyr.source()))
    rasterBand = rasterDataset.GetRasterBand(1)
    rasterArry = rasterBand.ReadAsArray()
    rasterArry[numpy.isnan(rasterArry)] = noData
    rasterArry = rasterArry.astype(dataType, copy=True)
    rasterBand.FlushCache()
    del rasterBand
    rasterDataset.FlushCache()
    del rasterDataset
    return rasterArry


def createRasterDataset(arry, noData, dataType, geoTransform, proj, outputFile):
    rows = arry.shape[0]
    cols = arry.shape[1]

    file, ext = os.path.splitext(outputFile)
    driverShortName = gdal_utils.getDriverByExt(ext)
    print(f"driverShortName: {driverShortName}")
    # driver = gdal.GetDriverByName("GTiff")
    gdal.AllRegister()
    driver = gdal.GetDriverByName(driverShortName)

    dataset = driver.Create(outputFile, cols, rows, 1, dataType)
    outBand = dataset.GetRasterBand(1)
    outBand.WriteArray(arry)
    outBand.SetNoDataValue(noData)

    # georeference the image and set the projection
    dataset.SetGeoTransform(geoTransform)
    dataset.SetProjection(proj)
    dataset = None
    del dataset

