    pgConnections=[]
    
    def __resetDB(self, dbName, connParams, feedback):
        #ogr.Open(outputGPkg, update=True).ExecuteSQL(f"DROP TABLE coastSnapped", dialect="OGRSQL")
        self.dropPGTable("streamcoast", dbName, connParams, feedback)
        self.dropPGTable("streamcoast_vertices_pgr", dbName, connParams, feedback)

    def exportStreamCoastToPG(self, lyr, table, dbName, connParams, crs, feedback):
        """
        Copy layer to postgres
        :param QgsVectorLayer streamsVectorLyr: layer to export to postgres database
        :param str table: "schema"."tablename"
        :param str dbName: database name
        :param dict connParams: connection parameters
        :param QgsCoordinateReferenceSystem crs: coordinate reference system
        :param QgsProcessingFeedback feedback: processing feedback
        :return: success
        :rtype: (bool)
        """

        self.showMessage("Exporting layer to postgres", feedback, ShowTo.All)
        geomType = "LINESTRING"
        key = 'fid'

        # self.showMessage(f"Adding {arcKeyFieldName} field", feedback, ShowTo.All)
        # self.addUniqueField(streamCoastLyr, arcKeyFieldName)

        pgConnString = f"dbname='{dbName}' host='{connParams['HOST']}' port='{str(connParams['PORT'])}' user='{connParams['USER']}' password='{connParams['PASSWORD']}' key={key} type={geomType} table={table} (geom)"
        self.showMessage(pgConnString, feedback, ShowTo.All)

        exportResult = QgsVectorLayerExporter.exportLayer(lyr, pgConnString, 'postgres', crs, False)
        if exportResult[0] == QgsVectorLayerExporter.NoError:
            self.showMessage(f"Success exporting [{exportResult[1]}]", feedback, ShowTo.All)
        else:
            raise QgsProcessingException(f"Error exporting [{exportResult[0]}] [{exportResult[1]}]")

    def createPGFromTo(self, tableName, idColName, dbName, connParams, feedback):
        """
        Creates From To topology using PostGIS pgr_createTopology
        :param str tableName: name of input table to create From To topology on.  source and target fields will be added to this table.
        :param str idColName: unique id column name
        :param str dbName: database name
        :param dict connParams: connection parameters
        :param QgsProcessingFeedback feedback: processing feedback
        :return: success
        :rtype: (bool)
        """

        try:
            pgConnString = f"dbname='{dbName}' host='{connParams['HOST']}' port='{str(connParams['PORT'])}' user='{connParams['USER']}' password='{connParams['PASSWORD']}'"
            conn = psycopg2.connect(pgConnString)
        except psycopg2.OperationalError as err:
            exc_type, exc_obj, exc_tb = sys.exc_info()
            raise QgsProcessingException(f"{err} {exc_type, exc_tb.tb_frame.f_code.co_filename, exc_tb.tb_lineno}")

        cur = conn.cursor()
        success = False
        try:
            #cur.execute(f"ALTER TABLE {tableName} ADD COLUMN {idColName} serial;")
            cur.execute(f"ALTER TABLE {tableName} ADD COLUMN source integer;")
            cur.execute(f"ALTER TABLE {tableName} ADD COLUMN target integer;")
            cur.execute(f"SELECT pgr_createTopology('{tableName}', 0.01, 'geom', '{idColName}');")
            cur.execute('COMMIT;')
            success = True
        except psycopg2.DatabaseError as err:
            exc_type, exc_obj, exc_tb = sys.exc_info()
            raise QgsProcessingException(f"{err} {exc_type, exc_tb.tb_frame.f_code.co_filename, exc_tb.tb_lineno}")
        finally:
            conn.close()
        return success

    def getFromToPGLayers(self, tableName, dbName, connParams, feedback):
        """
        Gets layers created by pgr_createTopology. [tableName] + [tableName]_vertices_pgr
        :param str tableName: name of input table to create From To topology on.  source and target fields will be added to this table.
        :param str dbName: database name
        :param dict connParams: connection parameters
        :param QgsProcessingFeedback feedback: processing feedback
        :return: from to layer and vertices layer
        :rtype: (QgsVectorLayer, QgsVectorLayer)
        """

        uri = QgsDataSourceUri()
        uri.setConnection(connParams['HOST'], str(connParams['PORT']), dbName, connParams['USER'], connParams['PASSWORD'])

        uri.setDataSource("public", tableName, "geom")
        fromToLyr = QgsVectorLayer(uri.uri(), tableName, "postgres")

        #fromToUri =  uri.uri()
        #self.showMessage(f"PostGIS layer {fromToLyr.name()} uri:{fromToUri} source:{fromToLyr.source()}", feedback, ShowTo.All)
        # if vlayer.isValid():
        #     self.showMessage(f"PostGIS layer loaded {vlayer.name()} uri:{uri.uri()}", feedback, ShowTo.All)
        #     project.addMapLayer(vlayer, True)
        # else:
        #     self.showMessage(f"PostGIS layer failed to load {vlayer.name()} uri:{uri.uri()}", feedback, ShowTo.All)

        tableName = f"{tableName}_vertices_pgr"
        uri.setDataSource("public", tableName, "the_geom")
        verticesUri = uri.uri()
        verticesLyr = QgsVectorLayer(uri.uri(), tableName, "postgres")

        #self.showMessage(f"PostGIS layer {verticesLyr.name()} uri:{verticesUri} source:{fromToLyr.source()}", feedback, ShowTo.All)
        # if vlayer.isValid():
        #     self.showMessage(f"PostGIS layer loaded {vlayer.name()} uri:{uri.uri()}", feedback, ShowTo.All)
        #     project.addMapLayer(vlayer, True)
        # else:
        #     self.showMessage(f"PostGIS layer failed to load {vlayer.name()} uri:{uri.uri()}", feedback, ShowTo.All)
        return (fromToLyr, verticesLyr)

    def dropPGTable(self, tableName, dbName, connParams, feedback):
        """
        Drop postgresql table.
        :param str tableName: table name to drop
        :param str dbName: database name
        :param dict connParams: connection parameters
        :param QgsProcessingFeedback feedback: processing feedback
        :return: success:
        :rtype: (bool)
        """

        try:
            pgConnString = f"dbname='{dbName}' host='{connParams['HOST']}' port='{str(connParams['PORT'])}' user='{connParams['USER']}' password='{connParams['PASSWORD']}'"
            conn = psycopg2.connect(pgConnString)
        except psycopg2.OperationalError as err:
            exc_type, exc_obj, exc_tb = sys.exc_info()
            raise QgsProcessingException(f"{err} {exc_type, exc_tb.tb_frame.f_code.co_filename, exc_tb.tb_lineno}")

        cur = conn.cursor()
        try:
            cur.execute(f"DROP TABLE IF EXISTS {tableName};")
            cur.execute('COMMIT;')
            success = True
        except psycopg2.DatabaseError as e:
            exc_type, exc_obj, exc_tb = sys.exc_info()
            self.showMessage(f"{e} {exc_type, exc_tb.tb_frame.f_code.co_filename, exc_tb.tb_lineno}", feedback, ShowTo.All)
        finally:
            conn.close()
        return success

    def createPGDatabase(self, dbName, connParams, feedback):
        """
        Create postgresql database
        :param str dbName: database name
        :param dict connParams: connection parameters
        :param QgsProcessingFeedback feedback: processing feedback
        :return: success:
        :rtype: (bool)
        """

        # connect to default postgresql database and create the new database dbName
        try:
            pgConnString = f"dbname='{self.DEFAULTPGDBNAME}' host='{connParams['HOST']}' port='{str(connParams['PORT'])}' user='{connParams['USER']}' password='{connParams['PASSWORD']}'"
            conn = psycopg2.connect(pgConnString)
        except psycopg2.OperationalError as err:
            exc_type, exc_obj, exc_tb = sys.exc_info()
            raise QgsProcessingException(f"{err} {exc_type, exc_tb.tb_frame.f_code.co_filename, exc_tb.tb_lineno}")

        conn.autocommit = True
        cur = conn.cursor()
        success = False
        try:
            cur.execute(sql.SQL(f"CREATE DATABASE {dbName};"))
            success = True
        except psycopg2.DatabaseError as err:
            exc_type, exc_obj, exc_tb = sys.exc_info()
            self.showMessage(f"{err} {exc_type, exc_tb.tb_frame.f_code.co_filename, exc_tb.tb_lineno}", feedback, ShowTo.All)
        finally:
            conn.close()
        return success

    def createPGExtensions(self, exts, dbName, connParams, feedback):
        """
        Create postgresql database.
        :param list exts: list of extensions to create within database
        :param str dbName: database name
        :param dict connParams: connection parameters
        :param QgsProcessingFeedback feedback: processing feedback
        :return: success:
        :rtype: (bool)
        """

        try:
            pgConnString = f"dbname='{dbName}' host='{connParams['HOST']}' port='{str(connParams['PORT'])}' user='{connParams['USER']}' password='{connParams['PASSWORD']}'"
            conn = psycopg2.connect(pgConnString)
        except psycopg2.OperationalError as err:
            exc_type, exc_obj, exc_tb = sys.exc_info()
            raise QgsProcessingException(f"{err} {exc_type, exc_tb.tb_frame.f_code.co_filename, exc_tb.tb_lineno}")

        conn.autocommit = True
        cur = conn.cursor()
        try:
            for ext in exts:
                cur.execute(sql.SQL(f"CREATE EXTENSION {ext};"))
        except psycopg2.DatabaseError as err:
            exc_type, exc_obj, exc_tb = sys.exc_info()
            raise QgsProcessingException(f"{err} {exc_type, exc_tb.tb_frame.f_code.co_filename, exc_tb.tb_lineno}")
        finally:
            conn.close()

    def createPGSchema(self, schemaName, connParams, feedback):
        """
        Create postgresql schema.
        :param dict connParams: connection parameters
        :param QgsProcessingFeedback feedback: processing feedback
        :return: success:
        :rtype: (bool)
        """

        # connect to default postgresql database and create the new schema
        try:
            pgConnString = f"dbname='{self.DEFAULTPGDBNAME}' host='{connParams['HOST']}' port='{str(connParams['PORT'])}' user='{connParams['USER']}' password='{connParams['PASSWORD']}'"
            conn = psycopg2.connect(pgConnString)
        except psycopg2.OperationalError as err:
            exc_type, exc_obj, exc_tb = sys.exc_info()
            raise QgsProcessingException(f"{err} {exc_type, exc_tb.tb_frame.f_code.co_filename, exc_tb.tb_lineno}")

        conn.autocommit = True
        cur = conn.cursor()
        success = False
        try:
            cur.execute(sql.SQL(f"CREATE SCHEMA {schemaName};"))
            success = True
        except psycopg2.DatabaseError as err:
            exc_type, exc_obj, exc_tb = sys.exc_info()
            self.showMessage(f"{err} {exc_type, exc_tb.tb_frame.f_code.co_filename, exc_tb.tb_lineno}", feedback, ShowTo.All)
        finally:
            conn.close()
        return success;

    def dropPGDatabase(self, dbName, connParams, feedback):
        """
        Drop postgresql database.
        :param str dbName: database name
        :param dict connParams: connection parameters
        :param QgsProcessingFeedback feedback: processing feedback
        :return: success:
        :rtype: (bool)
        """

        # connect to default postgresql database and drop database dbName
        try:
            pgConnString = f"dbname='{self.DEFAULTPGDBNAME}' host='{connParams['HOST']}' port='{str(connParams['PORT'])}' user='{connParams['USER']}' password='{connParams['PASSWORD']}'"
            conn = psycopg2.connect(pgConnString)
        except psycopg2.OperationalError as err:
            exc_type, exc_obj, exc_tb = sys.exc_info()
            raise QgsProcessingException(f"{err} {exc_type, exc_tb.tb_frame.f_code.co_filename, exc_tb.tb_lineno}")

        conn.autocommit = True
        cur = conn.cursor()
        success = False
        try:
            cur.execute(sql.SQL(f"DROP DATABASE {dbName};"))
            success = True
        except psycopg2.DatabaseError as err:
            exc_type, exc_obj, exc_tb = sys.exc_info()
            self.showMessage(f"{err} {exc_type, exc_tb.tb_frame.f_code.co_filename, exc_tb.tb_lineno}", feedback, ShowTo.All)
        finally:
            conn.close()
        return success;

    def getPGConnectionParams(self, pgConnSettings, pgAuthConnInfo):
        """
        Get and combine necessary postgressql connection and authentication parameters
        :param dict pgConnSettings: postgresql connection settings
        :param dict pgAuthConnInfo: postgresql authentication connection info
        :return: postgressql connection and authentication parameters
        :rtype: (dict)
        """

        try:
            host = pgConnSettings['host']
            port = pgConnSettings['port']
        except Exception as err:
            exc_type, exc_obj, exc_tb = sys.exc_info()
            raise QgsProcessingException(f"Key error getting connections setting.  Ensure connection is setup correctly in Datasource Manager -> PostgreSQL or select another connection with correct settings:\n"
                f" {repr(err)} {exc_type, exc_tb.tb_frame.f_code.co_filename, exc_tb.tb_lineno}")

        try:
            user = pgAuthConnInfo['username']
            password = pgAuthConnInfo['password']
        except Exception as err:
            exc_type, exc_obj, exc_tb = sys.exc_info()
            raise QgsProcessingException(f"Key error getting authentication setting.  Ensure authentication is setup correctly for the choosen connection in Datasource Manager -> PostgreSQL or select another connection with working username and password:\n"
                f"{repr(err)} {exc_type, exc_tb.tb_frame.f_code.co_filename, exc_tb.tb_lineno}")

        connParams = { 'HOST' : host, 'PORT' : port, 'USER' : user, 'PASSWORD' : password}
        return connParams

    def getPGConnections(self):
        """
        Gets list of postgresql connection names.
        :return: list of postgresql connection names
        :rtype: (list)
        """
        settings = QSettings()
        settings.beginGroup(f"/PostgreSQL/connections")
        conns = []
        for k in sorted(settings.allKeys()):
            sp = k.split('/')
            if len(sp) > 0 and not sp[0] in conns:
                print(k)
                conns.append(sp[0])
        return conns

    def getPGConnectionSettings(self, connName, feedback, parameters, context):
        """
        Gets postgresql connection info.
        :param str connName: connection name
        :return: authentication info
        :rtype: dict
        """
        self.showMessage(f"connName: {connName}", feedback, ShowTo.All)

        settings = QSettings()
        if not os.path.isfile(settings.fileName()):
            profileDir = self.parameterAsString(parameters, self.PROFILEDIR, context)
            qgisIniFilename = os.path.join(profileDir, "QGIS", "QGIS3.ini")
            if os.path.isfile(qgisIniFilename):
                self.showMessage(f"Using QGIS INI: {qgisIniFilename}", feedback, ShowTo.All)
                settings = QSettings(qgisIniFilename, QSettings.IniFormat)
            else:
                raise QgsProcessingException(f"QGIS3.ini does not exists: {qgisIniFilename}")

        #settings = QSettings(r"C:/Users/user/AppData/Roaming/QGIS/QGIS3/profiles/default/QGIS/QGIS3.ini", QSettings.IniFormat)
        #iniSettings = QSettings(settings.fileName(), QSettings.IniFormat)
        self.showMessage(f"settings.fileName: {settings.fileName()}", feedback, ShowTo.All)

        settings.beginGroup(f"/PostgreSQL/connections/{connName}")

        settingsDict = {}
        for k in settings.allKeys():
            settingsDict[k] = settings.value(k, '')

        return settingsDict

    def getPGAuthInfo(self, authConfId, feedback):
        """
        Gets postgresql authentication info.
        :param str authConfId: authentication config id
        :return: authentication info
        :rtype: dict
        """

        # create an empty auth method config object
        authConfig = QgsAuthMethodConfig()

        # get the application's authenticaion manager
        # load config from manager to the new config instance and decrypt sensitive data
        authManager = QgsApplication.authManager()

        # os.environ['QGIS_AUTH_DB_DIR_PATH'] = r"C:/Users/user/AppData/Roaming/QGIS/QGIS3/profiles/default/qgis-auth.db"
        #r = authManager.init(r"C:/Users/user/AppData/Roaming/QGIS/QGIS3/profiles/default/qgis-auth.db")
        # self.showMessage(f"authManager.authenticationDatabasePath(): {r} {authManager.authenticationDatabasePath()}", feedback, ShowTo.All)
        loadConfigResult = authManager.loadAuthenticationConfig(authConfId, authConfig, True)
        self.showMessage(f"loadConfigResult: {loadConfigResult}", feedback, ShowTo.All)
        self.showMessage(f"authManager.authenticationDatabasePath: {authManager.authenticationDatabasePath()}", feedback, ShowTo.All)

        authConfigDict = authConfig.configMap()
        return authConfigDict