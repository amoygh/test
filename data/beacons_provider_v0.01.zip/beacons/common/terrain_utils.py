import numpy
import math

from beacons.common import raster_utils

RowDirOffsets = numpy.array([-1, 0, 1, 1, 1, 0, -1, -1, 0], dtype=numpy.byte)
ColDirOffsets = numpy.array([1, 1, 1, 0, -1, -1, -1, 0, 0], dtype=numpy.byte)
CellDirDistView = numpy.array([math.sqrt(2), 1, math.sqrt(2), 1, math.sqrt(2), 1, math.sqrt(2), 1, 0], dtype=numpy.float32)

# elev, elevDiff, slope, i
class TerrainInfo():
    def __init__(self, x, y, elev, elevDiff, slope, dirIndex):
        self._x = x
        self._y = y
        self._elev = elev
        self._elevDiff = elevDiff
        self._slope = slope
        self._dirIndex = dirIndex

    @property
    def x(self):
        return self._x

    @x.setter
    def value(self, x):
        self._x = x

    @property
    def y(self):
        return self._y

    @y.setter
    def value(self, y):
        self._y = y

    @property
    def elev(self):
        return self._elev

    @elev.setter
    def value(self, elev):
        self._elev = elev

    @property
    def elevDiff(self):
        return self._elevDiff

    @elevDiff.setter
    def value(self, elevDiff):
        self._elevDiff = elevDiff

    @property
    def slope(self):
        return self._slope

    @slope.setter
    def value(self, slope):
        self._slope = slope

    @property
    def dirIndex(self):
        return self._dirIndex

    @dirIndex.setter
    def dirIndex(self, dirIndex):
        self._dirIndex = dirIndex


def getTerrainInfo(inputPt, demLyr):
    demInfo = raster_utils.getRasterInfo(demLyr)
    extent = demInfo.extent
    data = demInfo.data
    rows = demInfo.rows
    cols = demInfo.cols
    noData = demInfo.noData

    demWindowArry = numpy.zeros((3, 3))
    terrainInfoArry = numpy.empty((3, 3), dtype=TerrainInfo)

    inputRow = int(math.floor((extent.yMaximum() - inputPt.y()) / demInfo.cellHeight))
    inputCol = int(math.floor((inputPt.x() - extent.xMinimum()) / demInfo.cellWidth))

    inputCentX = extent.xMinimum() + (inputCol * demInfo.cellWidth + demInfo.cellWidth / 2)
    inputCentY = extent.yMaximum() - (inputRow * demInfo.cellHeight + demInfo.cellHeight / 2)

    centerElev = data[inputRow, inputCol]
    demWindowArry[1, 1] = centerElev
    terrainInfoArry[1, 1] = None

    # get terrain info for cells in window
    for i in range(RowDirOffsets.shape[0]):
        row = inputRow + RowDirOffsets[i]
        col = inputCol + ColDirOffsets[i]
        if row >= 0 and row < rows and col >= 0 and col < cols:
            elev = data[row, col]
            demWinRow = row - (inputRow - 1)
            demWinCol = col - (inputCol - 1)
            if elev != noData:
                elevDiff = centerElev - elev
                if CellDirDistView[i] != 0:
                    slope = elevDiff / CellDirDistView[i]
                else:
                    slope = 0
                x = inputCentX + ColDirOffsets[i] * demInfo.cellWidth
                y = inputCentY - RowDirOffsets[i] * demInfo.cellHeight
                terrainInfoArry[demWinRow, demWinCol] = TerrainInfo(x, y, elev, elevDiff, slope, i)
            else:
                terrainInfoArry[demWinRow, demWinCol] = None
        else:
            terrainInfoArry[demWinRow, demWinCol] = None

    sortedTerrainInfoList = sorted(terrainInfoArry.flatten(), key=lambda t: t.slope if t else -99999, reverse=True)
    #print("MULTIPOINT(" + ",".join([f"{info.x} {info.y}" for info in sortedTerrainInfoList if info]) + ")")
    return sortedTerrainInfoList



# def getWindowData(centerRow, centerCol, dataArry, demNoData):
#     rows = dataArry.shape[0]
#     cols = dataArry.shape[1]
#
#     windowArry = numpy.zeros((3, 3))
#     windowArry[1,1] = dataArry[centerRow, centerCol]
#     # get terrain info for cells in 3x3 window
#     for i in range(RowDirOffsets.shape[0] - 1):
#         row = centerRow + RowDirOffsets[i]
#         col = centerCol + ColDirOffsets[i]
#         if row >= 0 and row < rows and col >= 0 and col < cols:
#             # print(f"surfacePt: x:{surfacePt.x()}, y:{surfacePt.y()} r:{row} c:{col} dem:{demArry[row, col]}")
#             elev = dataArry[row, col]
#             demWinRow = row - (centerRow - 1)
#             demWinCol = col - (centerCol - 1)
#             if elev != demNoData:
#                 windowArry[demWinRow, demWinCol] = elev
#             else:
#                 windowArry[demWinRow, demWinCol] = None
#         else:
#             windowArry[demWinRow, demWinCol] = None
#     return windowArry
#
# def calculateWindowSlope(demArry):
#     slopeArry = numpy.zeros((3, 3))
#     centerElev = demArry[1, 1]
#     for i in range(RowDirOffsets.shape[0] - 1):
#         row = 1 + RowDirOffsets[i]
#         col = 1 + ColDirOffsets[i]
#         if row >= 0 and row < demArry.shape[0] and col >= 0 and col < demArry.shape[1]:
#             elev = demArry[row, col]
#             if elev:
#                 slopeArry[row, col] = (centerElev - elev) / CellDirDistView[i]
#             else:
#                 slopeArry[row, col] = None
#     return slopeArry
#
# def getSideDirIndex(dir):
#     rightOfDir = dir + 1
#     if rightOfDir > 7:
#         rightOfDir = 0
#
#     leftOfDir = dir - 1
#     if leftOfDir < 0:
#         leftOfDir = 7
#
#     return leftOfDir, rightOfDir