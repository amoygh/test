import math

from qgis.core import (
    QgsGeometry,
    QgsPointXY,
    QgsPolygon,
    QgsWkbTypes
)

def reverseGeometry(geom: QgsGeometry):
    if geom and not geom.isEmpty():
        nodes = geom.asPolyline()
        nodes.reverse()
        reversedGeom = QgsGeometry.fromPolylineXY(nodes)
        return reversedGeom
    else:
        return None

def multiToSinglePoly(inputPoly):
    polyList = []
    if inputPoly and not inputPoly.isEmpty():
        ringLineStringList = []
        absPoly = inputPoly.get()
        if inputPoly.isMultipart():
            for polyPart in range(absPoly.numGeometries()):
                ringLineStringList.append(absPoly.geometryN(polyPart).exteriorRing().clone())
        else:
            #ringLineStringList.append(absPoly.exteriorRing().clone())
            ringLineStringList.append(absPoly)

        for polyline in ringLineStringList:
            polyList.append(QgsPolygon((polyline)))
    return polyList

def getInteriorRings(inputPoly: QgsGeometry):
    innerRings = []
    if inputPoly and not inputPoly.isEmpty():
        if inputPoly.isMultipart():
            multiPoly = inputPoly.asMultiPolygon()
            for poly in multiPoly:
                # exterior ring always 0 index
                for i in range(1, len(poly)):
                    ring = poly[i]
                    #ringPoly = QgsGeometry.fromPolygonXY([ring])
                    innerRings.append(ring)
        else:
            poly = inputPoly.asPolygon()
            # exterior ring always 0 index
            for i in range(1, len(poly)):
                ring = poly[i]
                #ringPoly = QgsGeometry.fromPolygonXY([ring])
                innerRings.append(ring)
    return innerRings

def polygonToLines(inputPoly):
    if inputPoly and not inputPoly.isEmpty():
        polygonList = []
        if inputPoly.wkbType() == QgsWkbTypes.MultiPolygon:
            for poly in inputPoly.asMultiPolygon():
                polygonList.append(poly)
        elif inputPoly.wkbType() == QgsWkbTypes.Polygon:
            polygonList.append(inputPoly.asPolygon())

        if len(polygonList) > 0:
            polygonLines = polygonList[0]
            return polygonLines
    return None

def createCell(startPtXY, bearing, cellSizeX, cellSizeY):
    #bearing = 0
    cellPts = [startPtXY]
    #print(f"nbrCellPtXY:{startPtXY}")
    ptXY =  startPtXY
    for k in range(1, 4 + 1):
        cellSegAngle = (90 - (bearing + k * 90)) % 360
        cellSegX = math.cos(math.radians(cellSegAngle)) * cellSizeX
        cellSegY = math.sin(math.radians(cellSegAngle)) * cellSizeY
        ptXY = QgsPointXY(ptXY.x() + cellSegX, ptXY.y() + cellSegY)
        cellPts.append(ptXY)
        #print(f"nbrCellSegX:{cellSegX}  nbrCellSegY:{cellSegY} nbrCellPtXY:{ptXY}")
    cellGeom = QgsGeometry.fromPolygonXY([cellPts])
    return cellGeom