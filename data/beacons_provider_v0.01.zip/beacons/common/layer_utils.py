import os.path

from osgeo import ogr

import sqlite3


from .utils import (
    ShowTo,
    showMessage
)

from .layer_post_processor import LayerPostProcessor

from PyQt5.QtCore import (QMetaType, QVariant)
from qgis.core import (
    edit,
    QgsDefaultValue,
    QgsExpression,
    QgsExpressionContext,
    QgsExpressionContextUtils,
    QgsFeature,
    QgsField,
    QgsProcessingContext,
    QgsProcessingException,
    QgsProviderRegistry,
    QgsProject,
    QgsVectorDataProvider,
    QgsVectorFileWriter,
    QgsVectorLayer,
    QgsWkbTypes
)


def fieldExists(lyr, name):
    for fldName in lyr.fields().names():
        fieldName = str(fldName)
        if fieldName.upper() == name.upper():
            return True
    return False


def addField(lyr, field):
    if not fieldExists(lyr, field.name()):
        lyrDataProvider = lyr.dataProvider()
        if lyrDataProvider.capabilities() & QgsVectorDataProvider.AddAttributes:
            if lyrDataProvider.addAttributes([field]):
                lyr.updateFields()
                return True
        else:
            raise Exception(f"Error trying to add field {field.name()}. Layer data provider {lyrDataProvider.name()} does have capability to add attribute fields!")
    else:
        print(f"Field exists already. {field.name()}")
    return False


# def addField(lyr, field, defaultVal):
#     if addField(lyr, field):
#         fieldIdx = lyr.indexFromName(field.name())
#         lyr.setDefaultValueDefinition(fieldIdx, QgsDefaultValue('True'))
#         return True
#     return False


def addUniqueField(lyr, fieldName):
    lyrDataProvider = lyr.dataProvider()
    if lyrDataProvider.capabilities() & QgsVectorDataProvider.AddAttributes:
        if lyrDataProvider.addAttributes([QgsField(fieldName, QMetaType.Int)]):
            lyr.updateFields()
            fieldIdx = lyr.fields().indexFromName(fieldName)
            with edit(lyr):
                i = 1
                for feat in lyr.getFeatures():
                    lyr.changeAttributeValue(feat.id(), fieldIdx, i)
                    i += 1
            return True
        return False
    else:
        raise Exception(f"Error trying to add field {fieldName}. Layer data provider {lyrDataProvider.name()} does have capability to add attribute fields!")

def deleteFields(lyr, fieldNames):
    #print(lyr.dataProvider().capabilitiesString())
    lyrDataProvider = lyr.dataProvider()
    if lyrDataProvider.capabilities() & QgsVectorDataProvider.DeleteAttributes:
        #print(f"deleting fields...")
        deleteFldIdxList = []
        for fldName in fieldNames:
            fldIndex = lyr.fields().indexFromName(fldName)
            if fldIndex >= 0:
                deleteFldIdxList.append(fldIndex)

        if lyrDataProvider.deleteAttributes(deleteFldIdxList):
            #print(f"deleted fields: {deleteFldIdxList}")
            lyr.updateFields()
            return True
        else:
            #print(f"delete fields failed: {deleteFldIdxList}")
            pass
    else:
        raise Exception(f"Error trying to add fields {fieldNames}. Layer data provider {lyrDataProvider.name()} does have capability to delete attribute fields!")
    return False

def loadLayerOnCompletion(lyr, name, lyrPostProcessor, context, feedback):
    if lyr.isValid():
        showMessage(f"loading: {lyr}", feedback, ShowTo.All)
        context.temporaryLayerStore().addMapLayer(lyr)
        context.addLayerToLoadOnCompletion(lyr.id(), QgsProcessingContext.LayerDetails(name=name, project=context.project()))
        #lyrPostProcessor = LayerPostProcessor(name=name)
        context.layerToLoadOnCompletionDetails(lyr.id()).setPostProcessor(lyrPostProcessor)
    else:
        showMessage(f"loadLayerOnCompletion {name} not valid: {lyr.error().summary()}", feedback, ShowTo.All)
    return

def loadLayerIdOnCompletion(lyrId, name, context, feedback):
    global lyrPostProcessor
    lyrPostProcessor = LayerPostProcessor(name=name)
    context.layerToLoadOnCompletionDetails(lyrId).setPostProcessor(lyrPostProcessor)
    return

def loadRasterLayerOnCompletion(rasterLyr, name, lyrPostProcessor, context, feedback):
    if rasterLyr.isValid():
        showMessage(f"loading: {rasterLyr}", feedback, ShowTo.All)
        context.temporaryLayerStore().addMapLayer(rasterLyr)
        context.addLayerToLoadOnCompletion(rasterLyr.id(), QgsProcessingContext.LayerDetails(name=name, project=context.project()))
        #lyrPostProcessor = LayerPostProcessor(name=name)
        context.layerToLoadOnCompletionDetails(rasterLyr.id()).setPostProcessor(lyrPostProcessor)
    else:
        showMessage(f"rasterLyr.isValid:{rasterLyr.error().summary()}", feedback, ShowTo.All)
    return

def validateLayer(lyr, requiredGeomType):
    name = lyr.name()
    # self.showMessage(f"{name} layer: {lyr}", feedback, ShowTo.All)
    if lyr is not None:
        if not lyr.isValid():
            return False, f"\"{name}\" layer is invalid."

        wkbType = lyr.wkbType()
        geomType = lyr.geometryType()
        wkbTypeString = QgsWkbTypes.displayString(wkbType)
        geomTypeString = QgsWkbTypes.geometryDisplayString(geomType)
        if geomType != requiredGeomType:
            reqGeomTypeString = QgsWkbTypes.geometryDisplayString(requiredGeomType)
            msg = f"{reqGeomTypeString} geometry is required. Input layer \"{name}\" has {geomTypeString} geometry."
            return False, msg
    else:
        return False, f"\"{name}\" layer is not defined."
    return True, None

# def geoPackageLayerExists(lyrName, gpkg):
#     layers = fiona.listlayers(gpkg)
#     for lyr in layers:
#         print(lyr)
#         if lyr == lyrName:
#             return True
#     return False

def getRegisteredLayer(lyrId, lyrType):
    lyr = QgsProject.instance().mapLayers().get(lyrId)
    if isinstance(lyr, lyrType):
        return lyr
    else:
        return None

def geoPkgLayerExists(lyrName, gpkg):
    exists = False
    if os.path.isfile(gpkg):
        conn = sqlite3.connect(gpkg)
        cursor = conn.cursor()
        # gpkg_contents
        try:
            sqlite_select_query = """Select table_name from gpkg_contents"""
            cursor.execute(sqlite_select_query)
            records = cursor.fetchall()
            for row in records:
                name = row[0]
                #print(row)
                #print(name + " " + lyrName)
                if lyrName.upper() == name.upper():
                    exists = True
                    break
        except Exception as err:
            #exc_type, exc_obj, exc_tb = sys.exc_info()
            #raise Exception(f"###########{repr(err)} {exc_type, exc_tb.tb_frame.f_code.co_filename, exc_tb.tb_lineno}")
            exists = False
        finally:
            cursor.close()
            conn.close()
    else:
        raise Exception(f"Geopackage does not exists! - {gpkg}")
    return exists

def copyLayerToGeoPkg(lyr, name, gpkg, transfomContext, feedback):
    """
    Copy layer to geopackage
    :param QgsVectorLayer lyr: input layer
    :param str name: output layer name
    :param str gpkg: output gropackage
    :param QgsCoordinateTransformContext transfom context: transform context
    :param QgsProcessingFeedback feedback: processing feedback
    :return: layer in geopackage:
    :rtype: QgsVectorLayer
    """

    options = QgsVectorFileWriter.SaveVectorOptions()
    options.driverName = "GPKG"
    options.layerName = name

    if not os.path.isfile(gpkg):
        options.actionOnExistingFile = QgsVectorFileWriter.CreateOrOverwriteFile
    else:
        options.actionOnExistingFile = QgsVectorFileWriter.CreateOrOverwriteLayer

    #options.EditionCapability = QgsVectorFileWriter.CanAddNewLayer

    # project to another crs
    # crsSrc = QgsCoordinateReferenceSystem(3005)  # NAD83 Albers
    # crsDest = QgsCoordinateReferenceSystem(26911)  # NAD83 / UTM zone 11N
    # transform = QgsCoordinateTransform(crsSrc, crsDest, QgsProject.instance())
    # options.ct = transform
    # self.showMessage(f"copyLayerToGeoPkg({outLyrName}) sourceCrs:{lyr.sourceCrs()} coordinateOperations: {transformContext.coordinateOperations()}", feedback, ShowTo.All)

    outLyr = None
    writeResult = QgsVectorFileWriter.writeAsVectorFormatV3(lyr, gpkg, transfomContext, options)
    showMessage(f"copyLayerToGeoPkg input:{lyr.name()} output:{name} writeResult:{writeResult}", feedback, ShowTo.All)
    if writeResult[0] == QgsVectorFileWriter.NoError:
        msg = f"Success copying [{writeResult[0]}] [{writeResult[1]}] [{writeResult[2]}] [{writeResult[3]}]"
        showMessage(msg, feedback, ShowTo.All)
        newFilename = writeResult[2]
        newLayername = writeResult[3]
        outLyr = QgsVectorLayer(f"{newFilename}|layername={newLayername}", newLayername, "ogr")
        showMessage(f"copyLayerToGeoPkg outLyr:{outLyr.name()} name:{name} isValid:{lyr.isValid()}", feedback, ShowTo.All)
    else:
        raise QgsProcessingException(f"Error copying [{writeResult[0]}] [{writeResult[1]}] [{writeResult[2]}] [{writeResult[3]}]")

    #outLyr = QgsVectorLayer(f"{gpkg}|layername={name}", name, "ogr")
    # outLyrUri = QgsProviderRegistry.instance().decodeUri(outLyr.providerType(), outLyr.dataProvider().dataSourceUri())
    # showMessage(f"copyLayerToGeoPkg outLyr.name:{outLyr.name()} name:{name}\nsource:{outLyr.source()}\noutLyrUri:{outLyrUri}", feedback, ShowTo.All)

    #outLyrUri = QgsProviderRegistry.instance().decodeUri(outLyr.providerType(), outLyr.dataProvider().dataSourceUri())
    # msg = f"Copying outLyr:{outLyr} outLyrUri:{outLyrUri} -> {outputGPkg}"
    # self.showMessage(msg, feedback, ShowTo.All)
    #self.showMessage(f"{outLyr.name()} {uri} {str([f for f in outLyr.fields().names()])}", feedback, ShowTo.All)
    return outLyr

def copyLayerToGeoPkg2(lyr, name, gpkg, transfomContext, feedback):
    """
    Copy layer to geopackage
    :param QgsVectorLayer lyr: input layer
    :param str name: output layer name
    :param str gpkg: output gropackage
    :param QgsCoordinateTransformContext transfom context: transform context
    :param QgsProcessingFeedback feedback: processing feedback
    :return: layer in geopackage:
    :rtype: QgsVectorLayer
    """

    options = QgsVectorFileWriter.SaveVectorOptions()
    options.driverName = "GPKG"
    options.layerName = name

    if not os.path.isfile(gpkg):
        options.actionOnExistingFile = QgsVectorFileWriter.CreateOrOverwriteFile
    else:
        options.actionOnExistingFile = QgsVectorFileWriter.CreateOrOverwriteLayer

    #options.EditionCapability = QgsVectorFileWriter.CanAddNewLayer

    # project to another crs
    # crsSrc = QgsCoordinateReferenceSystem(3005)  # NAD83 Albers
    # crsDest = QgsCoordinateReferenceSystem(26911)  # NAD83 / UTM zone 11N
    # transform = QgsCoordinateTransform(crsSrc, crsDest, QgsProject.instance())
    # options.ct = transform
    # self.showMessage(f"copyLayerToGeoPkg({outLyrName}) sourceCrs:{lyr.sourceCrs()} coordinateOperations: {transformContext.coordinateOperations()}", feedback, ShowTo.All)

    outLyr = None
    err, writeResult = QgsVectorFileWriter. writeAsVectorFormatV2(lyr, gpkg, transfomContext, options)
    showMessage(f"copyLayerToGeoPkg2 input:{lyr.name()} output:{name} writeResult:{writeResult} err:{err}", feedback, ShowTo.All)
    if err == 0:
        #msg = f"Success copying [{writeResult[0]}] [{writeResult[1]}] [{writeResult[2]}] [{writeResult[3]}]"
        #showMessage(msg, feedback, ShowTo.All)
        #newFilename = writeResult[2]
        #newLayername = writeResult[3]
        outLyr = QgsVectorLayer(f"{gpkg}|layername={name}", name, "ogr")
        showMessage(f"copyLayerToGeoPkg2 outLyr:{outLyr.name()} name:{name} isValid:{lyr.isValid()}", feedback, ShowTo.All)
    else:
        raise QgsProcessingException(f"Error copying [{err}]")

    return outLyr

def deleteGPkgLayer(geoPkg, lyr, feedback):
    if os.path.isfile(geoPkg):
        gpkgDriver = ogr.GetDriverByName('GPKG')
        with gpkgDriver.Open(geoPkg, update=True) as gpkgDS:
            #lyr = QgsVectorLayer(geoPkg, "temp_lyr", "ogr")
            subLayers = lyr.dataProvider().subLayers()
            for subLayer in subLayers:
                subLayerSplit = subLayer.split('!!::!!')
                if len(subLayerSplit) > 0:
                    lyrName = subLayerSplit[1]
                    if geoPkgLayerExists(lyrName, geoPkg):
                        showMessage(f"Did not Delete layer: {lyrName}", feedback, ShowTo.All)
                        #gpkgDS.DeleteLayer(lyrName)


def calculateFieldExpr(lyr: QgsVectorLayer, fieldName, expr: QgsExpression, selected=False, additionalLyrs=None):
    exprContext = QgsExpressionContext()
    exprContext.appendScopes(QgsExpressionContextUtils.globalProjectLayerScopes(lyr))
    if additionalLyrs:
        for additionalLyr in additionalLyrs:
            exprContext.appendScopes(QgsExpressionContextUtils.globalProjectLayerScopes(additionalLyr))

    fieldIdx = lyr.fields().indexFromName(fieldName)
    # prepare expression for evaluation
    expr.prepare(exprContext)
    attrValueMap = {}
    for feature in lyr.getSelectedFeatures() if selected else lyr.getFeatures():
        exprContext.setFeature(feature)
        value = expr.evaluate(exprContext)
        attrValueMap[feature.id()] = { fieldIdx : value }
    lyr.dataProvider().changeAttributeValues(attrValueMap)

def doExpression(exprText, lyr, geom):
    feature = QgsFeature()
    feature.setGeometry(geom)
    expr = QgsExpression(exprText)
    exprContext = QgsExpressionContext()
    exprContext.appendScopes(QgsExpressionContextUtils.globalProjectLayerScopes(lyr))
    exprContext.setFeature(feature)
    result = expr.evaluate(exprContext)
    return result

