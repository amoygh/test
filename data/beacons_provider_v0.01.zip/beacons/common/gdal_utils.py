import os
from beacons.common import layer_utils
from osgeo import gdal

def createGeopackageRasterLayerTableOption_org(gpkg, lyrName, createGPkg):
    """
    Creates gdalwarp -co OPTION string that allows a raster layer to be appended to an existing geopackage.
    If the layer already exists in the outputGPkg, an exception is raised..
    If the createGPkg option is True and if the the ouputGPkg does not exists, a new geopackage is created with the raster layer.
    If the createGPkg option is False and if the the ouputGPkg does not exists, an exception is raised indicating the geopackage does not exists.
    See https://gdal.org/en/latest/drivers/raster/gpkg.html#raster-gpkg.
    :param QgsVectorLayer streamsVectorLyr: streams layer
    :param QgsCoordinateTransformContext transformContext: coordinate transform context
    :param str gpkg: path to output geopackage
    :param QgsProcessingFeedback feedback: processing feedback
    :return: streams layer with assigned stream net type code
    :rtype: (QgsVectorLayer)
    """

    if os.path.isfile(gpkg):
        if not layer_utils.geoPkgLayerExists(lyrName, gpkg):
            rastOptions = f'APPEND_SUBDATASET=YES|RASTER_TABLE={lyrName}'
        else:
            raise Exception(f"ERROR: Output exists already: {lyrName}")
    else:
        if createGPkg:
            # create new gpkg
            rastOptions = f'RASTER_TABLE={lyrName}'
        else:
            raise Exception(f"ERROR: Geopackage does not exists: {gpkg}")
    return rastOptions


def createGeopackageRasterTableOutputOption(lyrName, append):
    """
    Creates a gdal raster output creation option(-co) for geopackage format depending on if appending.
    When append parameter is True, the APPEND_SUBDATASET=YES|RASTER_TABLE={lyrName} statement is returned.
    When append parameter is False, the RASTER_TABLE={lyrName} option is returned.  Warning: this will overwrite the outputGPkg.
    """

    if append:
        rastOptions = f'APPEND_SUBDATASET=YES|RASTER_TABLE={lyrName}'
    else:
        rastOptions = f'RASTER_TABLE={lyrName}'
    return rastOptions


def getDriverByExt(ext):
    gdal.AllRegister()
    # dataSource = gdal.OpenEx(outputFile, 1)
    # driver = dataSource.GetDriver()
    # drivername = driver.ShortName
    # ShowTo(f"gdal drivername: {drivername}" , feedback, ShowTo.All)

    ext = ext.strip('.')
    for i in range(gdal.GetDriverCount()):
        driver = gdal.GetDriver(i)
        metadata = driver.GetMetadata_Dict()
        #if 'DCAP_RASTER' in metadata:
        #print(f"{driver.ShortName}|{driver.GetMetadataItem(gdal.DMD_LONGNAME)}|{driver.GetMetadataItem(gdal.DMD_EXTENSIONS)}")
        extText = driver.GetMetadataItem(gdal.DMD_EXTENSIONS)
        if extText is not None:
            exts = extText.split(' ')
            extsUpper = [ext.upper() for ext in exts]
            if ext.upper() in extsUpper:
                print(f"{driver.ShortName}|{driver.GetMetadataItem(gdal.DMD_LONGNAME)}|{driver.GetMetadataItem(gdal.DMD_EXTENSIONS)}")
                return driver.ShortName

    return None