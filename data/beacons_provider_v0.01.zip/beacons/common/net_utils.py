from . import collections


class Catchment(object):
    def __init__(self, catchnum, order1, order2, order3, basin):
        self._catchnum = catchnum
        self._order1 = order1
        self._order2 = order2
        self._order3 = order3
        self.order1_3 = order1 + order3
        self._basin = basin


    @property
    def catchnum(self):
        return self._catchnum

    @catchnum.setter
    def value(self, catchnum):
        self._catchnum = catchnum

    @property
    def order1(self):
        return self._order1

    @order1.setter
    def order1(self, order1):
        self._order1 = order1

    @property
    def order2(self):
        return self._order2

    @order2.setter
    def order2(self, order2):
        self._order2 = order2

    @property
    def order3(self):
        return self._order3

    @order3.setter
    def order3(self, order3):
        self._order3 = order3

    @property
    def basin(self):
        return self._basin

    @basin.setter
    def basin(self, basin):
        self._basin = basin

def order3ToOrder2(order3):
    base64Codes = ["0", "1", "2", "3", "4", "5", "6", "7", "8", "9", "=", "A", "B", "C", "D", "E", "F", "G", "H", "I", "J", "K", "L", "M", "N", "O", "P", "Q", "R", "S", "T", "U", "V", "W", "X", "Y",
                   "Z", "_", "a", "b", "c", "d", "e", "f", "g", "h", "i", "j", "k", "l", "m", "n", "o", "p", "q", "r", "s", "t", "u", "v", "w", "x", "y", "z"]

    idx0 = base64Codes.index(order3[0])
    idx1 = base64Codes.index(order3[1])
    order2 = idx0 * len(base64Codes) + idx1
    return order2



def isUpstream(currentCatch, otherCatch):
    # test if other catchment is upstream of current catchment
    isUpstream = False

    # (basin = BASIN and order1 = ORDER1 and order2 >= ORDER2)
    if otherCatch.basin == currentCatch.basin:
        if otherCatch.order1 == currentCatch.order1:
            if otherCatch.order2 >= currentCatch.order2:
                isUpstream = True

    # do next only if nothing was found in previous query
    if not isUpstream:
        # (basin = BASIN and order1 contains ORDER1 and order1 > ORDER1.ORDER3)
        if otherCatch.basin == currentCatch.basin:
            if otherCatch.order1.find(currentCatch.order1) >= 0:
                if (otherCatch.order1 > currentCatch.order1_3):
                    isUpstream = True
    return isUpstream;



# test if other catchment is downstream of current catchment
def isDownstream(currentCatch, otherCatch):
    """
    Test if current catchment is downstream of current catchment.  This is slightly different from isDownstreamSameStream where other order2 must be less than current order2.
    :param currentCatch:
    :param otherCatch:
    :return:
    """
    isDownstream = False
    # basin = BASIN and order1 = ORDER1 and order2 < ORDER2
    if otherCatch.basin == currentCatch.basin:
        # must test ordinal because of case sensitivity
        if otherCatch.order1 == currentCatch.order1:
            if otherCatch.order2 < currentCatch.order2:
                isDownstream = True
    return isDownstream


def isDownstreamSameStream(currentCatch, otherCatch):
    """
    Test if current catchment is downstream of current catchment.  This is slightly different from isDownstream where other order2 can be equal or less than current order2.
    :param currentCatch:
    :param otherCatch:
    :return:
    """
    isDownstream = False

    # (basin = BASIN and order1 = ORDER1 and order2 <= ORDER2)
    if otherCatch.basin == currentCatch.basin:
        # must test ordinal because of case sensitivity
        if otherCatch.order1 == currentCatch.order1:
            if otherCatch.order2 <= currentCatch.order2:
                isDownstream = True
    return isDownstream


# test if other catchment is downstream of current catchment
# def isNextDownstream(self, currentCatch, otherCatch):
#     isNextDownstream = False
#     # (basin = BASIN and order1 = ORDER1 and order2 < ORDER2)
#     if otherCatch.basin == currentCatch.basin:
#         # must test ordinal because of case sensitivity
#         if otherCatch.order1 == currentCatch.order1:
#             if otherCatch.order2 <= currentCatch.order2 + 1:
#                 isNextDownstream = True
#     return isNextDownstream

def getNextOrder(currentOrder1, i):
    nextOrd1Pos = len(currentOrder1) - (i * 3)
    nextOrder1 = currentOrder1[0:nextOrd1Pos]
    nextOrd3Pos = len(currentOrder1) - (i * 3)
    nextOrder3 = currentOrder1[nextOrd3Pos:nextOrd3Pos + 2]
    if nextOrder3.find(".") == -1:
        nextOrder2 = order3ToOrder2(nextOrder3)
    else:
        nextOrder2 = -1
    return nextOrder1, nextOrder2

def isNextDownstream(otherOrder1, otherOrder2, currentOrder1):
    nextOrder1 = ""
    nextOrder3 = ""
    nextOrder2 = 0
    isNextDownStreamFound = False

    count = (len(currentOrder1) / 3) - 1
    i = 1
    while i <= count and not isNextDownStreamFound:
        # nextOrd1Pos = len(currentOrder1) - (i * 3)
        # nextOrder1 = currentOrder1[0:nextOrd1Pos]
        # nextOrd3Pos = len(currentOrder1) - (i * 3)
        # nextOrder3 = currentOrder1[nextOrd3Pos:nextOrd3Pos + 2]
        # nextOrder2 = order3ToOrder2(nextOrder3)
        nextOrder1, nextOrder2 = getNextOrder(currentOrder1, i)
        i += 1

        if otherOrder1 == nextOrder1:
            if otherOrder2 <= nextOrder2 + 1:
                # print(f"currentOrder1:{currentOrder1} otherOrder1:{otherOrder1} otherOrder2:{otherOrder2}")
                # print(f"nextOrder1:{nextOrder1} nextOrder2:{nextOrder2} nextOrder3:{nextOrder3}")
                return True
    return False


def isNextDownstream2(currentCatch, otherCatch):
    # test if other catchment is downstream of current catchment
    isNextDownstream = False
    if otherCatch.basin == currentCatch.basin:
        if otherCatch.order1 == currentCatch.order1:
            if otherCatch.order2 <= currentCatch.order2 + 1:
                isNextDownstream = True
    return isNextDownstream


def getDownstreamCatchments(inputCatchNums, catchmentsLyr, catchDict, nbrDict):
    downstreamCatchments = []
    isInspectedNumList = []

    for inputCatchNum in inputCatchNums:
        # create queue to hold pending catchments to be inspected
        inputCatch = catchDict[inputCatchNum]
        if inputCatchNum in catchDict:
            pendingCatchQueue = collections.Queue()
            pendingCatchQueue.enqueue(inputCatch)

            while pendingCatchQueue.size() > 0:
                currentCatch = pendingCatchQueue.dequeue();
                #nbrFeatIds = layer_utils.doExpression(f"overlay_touches('{catchmentsLyr.id()}', $id)", catchmentsLyr, currentInputCatchFeat.geometry())
                if currentCatch.catchnum in nbrDict:
                    currentCatchNbrNums = nbrDict[currentCatch.catchnum]
                    #currentCatchNbrNums.sort()
                    #print(str(currentCatch.catchnum) +  " " + str([n for n in currentCatchNbrNums]))
                    for currentNbrCatchNum in currentCatchNbrNums:
                        if currentNbrCatchNum in catchDict:
                            nbrCatch = catchDict[currentNbrCatchNum]
                            if currentNbrCatchNum not in isInspectedNumList:
                                if currentNbrCatchNum not in inputCatchNums:
                                    # is downstream of current aggregated catchment
                                    if isDownstream(inputCatch, nbrCatch):
                                        # add to downstream list and put this catchment into queue, so its neighbours can be inspected
                                        downstreamCatchments.append(nbrCatch)
                                        pendingCatchQueue.enqueue(nbrCatch)
                                        isInspectedNumList.append(nbrCatch.catchnum)

                                        # print(f"pendingCatchQueue1: {[c.catchnum for c in pendingCatchQueue.items]}")
                                        # print(f"isInspectedNumList1: {[n for n in isInspectedNumList]}")
                                    else:
                                        # is neighbour next downstream of current aggregated catchment ORDER1 part
                                        nextOrder1 = ""
                                        nextOrder3 = ""
                                        nextBasin = 0
                                        nextOrder2 = 0

                                        currentCatchOrder1 = inputCatch.order1
                                        isOrder2Found = False
                                        isNextDownStreamFound = False
                                        # ORDER1 parts to check
                                        count = (len(currentCatchOrder1) / 3) - 1
                                        i = 1

                                        while i <= count and not isNextDownStreamFound:
                                            # nextOrder1 = currentCatchOrder1.Substring(0, currentCatchOrder1.Length - (i * 3));
                                            # nextOrder3 = currentCatchOrder1.Substring(currentCatchOrder1.Length - (i * 3), 2);
                                            nextOrd1Pos = len(currentCatchOrder1) - (i * 3)
                                            nextOrder1 = currentCatchOrder1[0:nextOrd1Pos]
                                            nextOrd3Pos = len(currentCatchOrder1) - (i * 3)
                                            nextOrder3 = currentCatchOrder1[nextOrd3Pos:nextOrd3Pos + 2]
                                            nextBasin = inputCatch.basin

                                            # find matching stream catchment with same next order1 and next order3
                                            # note, the expected catchment may not exist due to construction eliminating or order gap
                                            # this may may need to be relaxed, so that gaps in the order can be handled
                                            # eg. looking for next .005g1 186, but .005g1 184 only exists, which is obviously downstream but ignored
                                            strictNextDownstream = False;
                                            nextOrder2 = order3ToOrder2(nextOrder3)
                                            isOrder2Found = True

                                            i += 1
                                            if isOrder2Found:
                                                nextCatch = Catchment(-1, nextOrder1, nextOrder2, nextOrder3, nextBasin)
                                                # is downstream neighbour
                                                if isNextDownstream2(nextCatch, nbrCatch):
                                                    # add to downstream list and put this catchment into queue, so its neighbours can be inspected
                                                    downstreamCatchments.append(nbrCatch)
                                                    pendingCatchQueue.enqueue(nbrCatch)
                                                    isInspectedNumList.append(nbrCatch.catchnum)
                                                    isNextDownStreamFound = True
                                                    # print(f"pendingCatchQueue2: {[c.catchnum for c in pendingCatchQueue.items]}")
                                                    # print(f"isInspectedNumList2: {[n for n in isInspectedNumList]}")
                                                else:
                                                    pass
                                else:
                                    pendingCatchQueue.enqueue(nbrCatch)
                                    isInspectedNumList.append(nbrCatch.catchnum)
                                    # print(f"pendingCatchQueue3: {[c.catchnum for c in pendingCatchQueue.items]}")
                                    # print(f"isInspectedNumList3: {[n for n in isInspectedNumList]}")
                        else:
                            print(f"currentNbrCatchNum: {currentNbrCatchNum} not in catchDict")
                else:
                    pass
        else:
            print(f"inputCatchNum: {inputCatchNum} not in catchDict")

    if len(downstreamCatchments) > 0 and downstreamCatchments[len(downstreamCatchments) - 1].catchnum == 16134:
        pass

    #downstreamCatchments.sort(key=lambda c: c.order1_3, reverse=True)
    downstreamCatchments = reorderCatchmentsDownstream(downstreamCatchments)

    #print(f"PB{inputCatchNums[0]},PB_{inputCatchNums[0]}," + ",".join([str(c.catchnum) for c in downstreamCatchments]))
    return downstreamCatchments

def reorderCatchmentsDownstream(downstreamCatchments):
    downstreamOrderedCatchments = []
    for insertCatch in downstreamCatchments:
        downstreamOrderedCatchments.append(insertCatch)
        i = len(downstreamOrderedCatchments) - 2
        while i >= 0:
            if isUpstream(insertCatch, downstreamOrderedCatchments[i]):
                # stop when a more upstream catchment is encountered
                break
            else:
                # move current item down
                downstreamOrderedCatchments[i + 1] = downstreamOrderedCatchments[i]
            i -= 1
        i += 1
        downstreamOrderedCatchments[i] = insertCatch
    return downstreamOrderedCatchments