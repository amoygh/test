import os

from enum import IntEnum

from osgeo import gdal
from osgeo import ogr

from qgis.core import (
    QgsMessageLog,
    QgsVectorLayer
)



def purgeFiles(outputFolder, outputGPkgName, feedback):
    # delete all layers in outputGPkg, delete POSTGIS tables streamcoast, streamcoast_vertices_pgr,
    outputGPkg = os.path.join(outputFolder, outputGPkgName)
    resetGPkg(outputGPkg, feedback)
    deleteGPkg(os.path.join(outputFolder, "streamCoastClean.gpkg"), feedback)
    deleteFiles(outputFolder, ["streamcoast.net.bak", "streamcoast.net.dat", "streamcoast.net.dir"], feedback)
    deleteFiles(outputFolder, ["streamcoast_aat.csv", "streamcoast_nat.csv"], feedback)
    deleteFiles(outputFolder, ["streamcoast_arcdata.csv", "streamcoast_nodedata.csv", "streamcoast_arcdata.csvt"], feedback)
    # self.__resetDB(tempDBName, connParams, feedback)


def resetGPkg(geoPkg, feedback):
    if os.path.isfile(geoPkg):
        gpkgDriver = ogr.GetDriverByName('GPKG')
        with gpkgDriver.Open(geoPkg, update=True) as gpkgDS:
            lyr = QgsVectorLayer(geoPkg, "temp_lyr", "ogr")
            subLayers = lyr.dataProvider().subLayers()
            for subLayer in subLayers:
                subLayerSplit = subLayer.split('!!::!!')
                if len(subLayerSplit) > 0:
                    lyrName = subLayerSplit[1]
                    if layer_utils.geoPackageLayerExists(lyrName, geoPkg):
                        showMessage(f"Deleting layer: {lyrName}", feedback, ShowTo.All)
                        gpkgDS.DeleteLayer(lyrName)
    # else:
    #     self.showMessage(f"Error resetting geopackage. Does not exists: {geoPkg}", feedback, ShowTo.All)


def deleteGPkg(gpkgFilename, feedback):
    if os.path.isfile(gpkgFilename):
        showMessage(f"Deleting geopackage: {gpkgFilename}", feedback, ShowTo.All)
        os.remove(gpkgFilename)


def deleteFiles(dir, filenames, feedback):
    for name in filenames:
        filename = os.path.join(dir, name)
        if os.path.isfile(filename):
            showMessage(f"Deleting filename: {filename}", feedback, ShowTo.All)
            os.remove(filename)


class ShowTo(IntEnum):
    FeedbackProgressText = 1 << 0
    MessageLog = 1 << 1
    Print = 1 << 2
    All = FeedbackProgressText | MessageLog | Print

def showMessage(msg, feedback, output:ShowTo):
    #print(f"output{output} ShowTo.All{ShowTo.All} ShowTo.Print{ShowTo.Print} output & ShowTo.Print:{output & ShowTo.Print}")
    if feedback != None and output & ShowTo.FeedbackProgressText == ShowTo.FeedbackProgressText:
        feedback.setProgressText(msg)
    if output & ShowTo.MessageLog == ShowTo.MessageLog:
        QgsMessageLog.logMessage(msg)
    if output & ShowTo.Print == ShowTo.Print:
        print(msg)

def showSeparator(feedback):
    showMessage("----------------------------------------------------------------------------------------------", feedback, ShowTo.All)