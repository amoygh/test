from qgis.core import QgsProcessingLayerPostProcessorInterface

class LayerPostProcessor(QgsProcessingLayerPostProcessorInterface):
    def __init__(self):
        self.name = None
        super().__init__()

    def __init__(self, name):
        print("LayerPostProcessor:" + name)
        self.name = name
        super().__init__()

    def postProcessLayer(self, layer, context, feedback):
        print("postProcessLayer:" + self.name)
        #if self.name is not None:
        layer.setName(self.name)