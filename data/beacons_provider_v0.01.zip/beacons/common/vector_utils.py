import time

from PyQt5.QtCore import (QMetaType)
from qgis.core import (
    QgsExpression,
    QgsFeature,
    QgsField,
    QgsWkbTypes
)

from . import layer_utils

def createNeighboursLookup(lyr, idFieldName):
    """
    Creates a polygon neighbour lookup dictionary.  The neighbours for each feature with the same id field value are packed as unique list of ids.
    :param lyr: the input layer to determine the neighbours
    :param idFieldName: the name of the field that uniquely identifies the feature(s) to determine the neighbours for
    :param nbrAsFid: neighbour uses feature fid instead of idFieldName value for neighbour id
    :return: dictionary of neighbour ids, which can be idFieldName values or fids depending on nbrAsFid parameter
    :rtype: dict[int, list[int]]
    """
    start_time = time.time()
    usingFid = idFieldName == '$id'
    nbrDict = {}
    expr = f"overlay_touches('{lyr.id()}', $id)" if usingFid else f"overlay_touches('{lyr.id()}', {"$id" if usingFid else "\"" + idFieldName + "\""})"
    for f in lyr.getFeatures():
        #print(f.id())
        nbrIds = layer_utils.doExpression(expr, lyr, f.geometry())
        if nbrIds:
            #print([fld.name() for fld in f.fields()])
            id = f.id() if usingFid else f.attribute(idFieldName)
            if not id in nbrDict:
                nbrDict[id] = []

            for nbrId in nbrIds:
                if nbrId != id:
                    nbrInt = f.geometry().intersection(lyr.getFeature(nbrId).geometry())
                    if nbrInt.wkbType() != QgsWkbTypes.Point:
                        nbrDict[id].append(nbrId)
            noDups = list(set(nbrDict[id]))
            nbrDict[id] = noDups
        else:
            pass
    print(f"createNeighboursLookup: {time.time() - start_time} seconds")
    return nbrDict